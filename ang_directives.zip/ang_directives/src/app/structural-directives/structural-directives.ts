import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structural-directives',
  imports: [CommonModule],
  templateUrl: './structural-directives.html',
  styleUrl: './structural-directives.css',
})
export class StructuralDirectives {
  //---- ngif
isLoggedIn: boolean = false;
login(){
  this.isLoggedIn = true;
}
logout(){
  this.isLoggedIn = false;    
}

//----- ngfor
courses : string[] = ['Angular', 'React', 'Vue', 'NodeJS', 'Django']

 role: string = '';
 setrole(newrole:string){
    this.role = newrole;

 }

}