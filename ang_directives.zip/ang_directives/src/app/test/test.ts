import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {
name:string="DAMODHARAN";   
age:number=25;
address:string="Chennai"; 
}
