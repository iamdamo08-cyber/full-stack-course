package com.example.demo.Repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entityormodel.Employee;

public interface MyRepos extends JpaRepository<Employee, Integer>{

}