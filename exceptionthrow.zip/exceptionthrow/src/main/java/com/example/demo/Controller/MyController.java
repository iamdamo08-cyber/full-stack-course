package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entityormodel.Employee;
import com.example.demo.services.MyService;

@RestController
@RequestMapping("/employee")   // Base URL
public class MyController {

    @Autowired
    private MyService service;

    // GET ALL
    @GetMapping
    public List<Employee> getAllEmployee() {
        return service.getAllEmployee();
    }

    // GET BY ID
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable int id) {
        return service.getEmployeebyId(id);
    }

    // ADD
    @PostMapping
    public String addEmployee(@RequestBody Employee employee) {
        return service.addEmployee(employee);
    }

    // UPDATE
    @PutMapping("/{id}")
    public String updateEmployee(@PathVariable int id,
                                 @RequestBody Employee updatedEmployee) {
        return service.updateEmployee(id, updatedEmployee);
    }

    // DELETE BY ID
    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteEmployee(id);
    }

    // DELETE ALL
    @DeleteMapping
    public String deleteAllEmployee() {
        return service.deleteAllEmployee();
    }
}