package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionthrowApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionthrowApplication.class, args);
		System.out.println("Spring boot demo 2 application is working");
	}

}
