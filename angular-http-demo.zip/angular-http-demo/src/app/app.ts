import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HttpClientModule], // Import modules here
  template: `
    <h1>Angular HTTP Methods Demo</h1>

    <button (click)="getUsers()">GET All Users</button>
    <button (click)="getUser()">GET User by ID</button>
    <button (click)="addUser()">POST User</button>
    <button (click)="updateUser()">PUT User</button>
    <button (click)="patchUser()">PATCH User</button>
    <button (click)="deleteUser()">DELETE User</button>

    <pre>{{ result | json }}</pre>
  `
})
export class AppComponent {
  result: any;

  constructor(private userService: UserService) {}

  getUsers() {
    this.userService.getUsers().subscribe(res => this.result = res);
  }

  getUser() {
    this.userService.getUserById(1).subscribe(res => this.result = res);
  }

  addUser() {
    const newUser = { name: 'John Doe', email: 'john@example.com' };
    this.userService.addUser(newUser).subscribe(res => this.result = res);
  }

  updateUser() {
    const updatedUser = { name: 'Jane Doe', email: 'jane@example.com' };
    this.userService.updateUser(1, updatedUser).subscribe(res => this.result = res);
  }

  patchUser() {
    const partialUpdate = { email: 'newemail@example.com' };
    this.userService.patchUser(1, partialUpdate).subscribe(res => this.result = res);
  }

  deleteUser() {
    this.userService.deleteUser(1).subscribe(res => this.result = res);
  }
}