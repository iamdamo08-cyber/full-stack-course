import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'  // Makes the service available globally
})
export class UserService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/users'; // Demo API

  constructor(private http: HttpClient) { }

  // GET all users
  getUsers(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  // GET user by ID
  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  // POST new user
  addUser(user: any): Observable<any> {
    return this.http.post(this.apiUrl, user);
  }

  // PUT (update entire user)
  updateUser(id: number, user: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, user);
  }

  // PATCH (update partial user)
  patchUser(id: number, user: any): Observable<any> {
    return this.http.patch(`${this.apiUrl}/${id}`, user);
  }

  // DELETE user
  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}