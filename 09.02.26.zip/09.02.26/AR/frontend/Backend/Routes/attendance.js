const express = require("express");
const router = express.Router();
const Attendance = require("../models/Attendance");

router.post("/mark", async(req,res)=>{
    const record = new Attendance(req.body);
    await record.save();
    res.json({msg:"Attendance marked"});
});

router.get("/", async(req,res)=>{
    const data = await Attendance.find();
    res.json(data);
});

module.exports = router;
