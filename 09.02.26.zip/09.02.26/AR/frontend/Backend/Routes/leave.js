const express = require("express");
const router = express.Router();
const Leave = require("../models/Leave");

router.post("/apply", async(req,res)=>{
    const leave = new Leave(req.body);
    await leave.save();
    res.json({msg:"Leave applied"});
});

router.post("/update/:id", async(req,res)=>{
    await Leave.findByIdAndUpdate(req.params.id, req.body);
    res.json({msg:"Leave updated"});
});

router.get("/", async(req,res)=>{
    const leaves = await Leave.find();
    res.json(leaves);
});

module.exports = router;
