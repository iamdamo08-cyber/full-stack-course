const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
    staff: String,
    date: String,
    status: String // Present / Absent / Leave
});

module.exports = mongoose.model("Attendance", attendanceSchema);
