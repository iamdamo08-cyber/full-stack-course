const mongoose = require("mongoose");

const leaveSchema = new mongoose.Schema({
    staff: String,
    date: String,
    reason: String,
    status: { type: String, default: "Pending" }
});

module.exports = mongoose.model("Leave", leaveSchema);
