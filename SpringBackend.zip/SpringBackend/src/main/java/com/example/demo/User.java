package com.example.demo;

public class User {
    // Encapsulation: Private variables hide data from outside classes
    private String username; 
    private String password;
    private String dependencyMessage; 

    // REQUIRED for ApiController: Getter for username
    // The highest visibility modifier is 'public'
    public String getUsername() {
        return username;
    }

    // Public Setter for username
    public void setUsername(String username) {
        this.username = username;
    }

    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * REQUIREMENT: Setter Injection Implementation
     * This allows Spring to inject logic after the object is created.
     */
    public void setDependencyMessage(String message) {
        this.dependencyMessage = message;
    }

    public String showInjection() {
        return "The injected message is: " + this.dependencyMessage;
    }

    // Common logic from User class to be shared via Inheritance
    public void commonLogic() {
        System.out.println("Executing shared logic from User class.");
    }
}