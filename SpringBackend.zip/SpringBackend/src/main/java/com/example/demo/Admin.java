package com.example.demo;

/**
 * REQUIREMENT: Inheritance
 * Admin inherits from User using the 'extends' keyword.
 * This allows Admin to reuse common logic and variables from the User class.
 */
public class Admin extends User { 

    /**
     * REQUIREMENT: Custom Logic / Method Overriding
     * This method provides specific information for the Admin role.
     * It resolves the error on line 22 of your SpringBackendApplication.
     */
    public String getRoleInfo() {
        // Reuses the structure of User but adds custom logic
        return "This is an Admin with elevated privileges.";
    }
}