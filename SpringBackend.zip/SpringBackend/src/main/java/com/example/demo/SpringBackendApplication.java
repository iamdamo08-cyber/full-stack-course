package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication; // Added missing import

@SpringBootApplication // Requirement: Marks the main Spring Boot class
public class SpringBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBackendApplication.class, args);

        // SCENARIO: Explaining DI via Constructor vs Setter
        
        // 1. Setter Injection Example
        User userObj = new User(); 
        userObj.setDependencyMessage("Injected via Setter!"); // Setter Injection
        System.out.println(userObj.showInjection());

        // 2. Inheritance & Encapsulation Test
        Admin adminObj = new Admin();
        adminObj.setUsername("Admin_User"); // Inherited from User
        System.out.println("Role: " + adminObj.getRoleInfo());
    } // This brace closes the main method
} // This brace closes the class