package com.example.demo;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController {

    @GetMapping("/test") // Maps HTTP GET requests
    public String getData() {
        return "GET Request Successful!";
    }

    @PostMapping("/test")
    public String postData(@RequestBody User user) {
        // Ensure User.java has a getUsername() method
        return "POST Request Successful for: " + user.getUsername();
    }
}