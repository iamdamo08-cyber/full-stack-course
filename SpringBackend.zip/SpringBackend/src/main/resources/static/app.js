//Define the AngularJS Module
var app = angular.module('myApp', []);

/**
 * REQUIREMENT: Dependency Injection (DI) Implementation
 * This is Constructor Injection: $http and $scope are automatically 
 * injected by the AngularJS framework when the controller is created.
 */
app.controller('MainController', function($scope, $http) {
    
    // Initializing the model for Two-Way Data Binding
    $scope.user = {};
    $scope.message = "Fill out the form to test validation.";

    // Function to explain DI in the console
    $scope.explainDI = function() {
        console.log("AngularJS uses Constructor Injection to provide the $http service.");
    };

    /**
     * REQUIREMENT: Implementation of all HTTP methods
     */

    // 1. POST: Used to create data (Triggered by form submission)
    $scope.submitForm = function() {
        $http.post('/api/test', $scope.user).then(function(response) {
            // Success callback
            $scope.message = "Success! Server says: " + response.data;
        }, function(error) {
            // Error callback
            $scope.message = "Error occurred during POST request.";
        });
    };

    $scope.testOtherMethods = function() {
        // 2. GET: Retrieve data from the server
        $http.get('/api/test').then(function(res) { 
            console.log("GET Response:", res.data); 
        });
        
        // 3. PUT: Update existing data (e.g., updating user ID 1)
        $http.put('/api/test/1', { status: 'updated' }).then(function(res) {
            console.log("PUT Response: Data Updated");
        });
        
        // 4. DELETE: Remove data from the server
        $http.delete('/api/test/1').then(function(res) {
            console.log("DELETE Response: Data Removed");
        });
    };

    // Call explanation on load
    $scope.explainDI();
});