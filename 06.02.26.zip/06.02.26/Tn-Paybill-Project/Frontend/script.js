File: frontend/script.js
// script.js

let captchaValue = "";

function generateCaptcha() {
    captchaValue = Math.floor(1000 + Math.random() * 9000).toString();
    document.getElementById("captchaText").innerText = captchaValue;
}

generateCaptcha();

function login() {
    const userType = document.getElementById("userType").value;
    const userId = document.getElementById("userId").value;
    const password = document.getElementById("password").value;
    const captchaInput = document.getElementById("captchaInput").value;
    const message = document.getElementById("message");

    if (captchaInput !== captchaValue) {
        message.style.color = "red";
        message.innerText = "Invalid Captcha ❌";
        generateCaptcha();
        return;
    }

    fetch("http://localhost:3000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userType, userId, password })
    })
    .then(res => res.json())
    .then(data => {
        message.style.color = data.success ? "green" : "red";
        message.innerText = data.message;
    });
}

// ---------- END OF script.js ----------
