package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "*")   // prevents CORS issues
public class StudentController {

    @Autowired
    private StudentRepository repo;

    // ✅ POST – Create Student
    @PostMapping
    public ResponseEntity<Student> addStudent(@RequestBody Student student) {
        Student saved = repo.save(student);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // ✅ GET – Get All Students
    @GetMapping
    public ResponseEntity<List<Student>> getAllStudents() {
        return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
    }

    // ✅ GET – Get Student By ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable Integer id) {

        Optional<Student> student = repo.findById(id);

        if (student.isPresent()) {
            return new ResponseEntity<>(student.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Student not found", HttpStatus.NOT_FOUND);
        }
    }

    // ✅ PUT – Update Student
    @PutMapping("/{id}")
    public ResponseEntity<?> updateStudent(@PathVariable Integer id,
                                           @RequestBody Student updatedStudent) {

        return repo.findById(id).map(existing -> {

            existing.setName(updatedStudent.getName());
            existing.setCourse(updatedStudent.getCourse());

            Student saved = repo.save(existing);

            return ResponseEntity.ok(saved);

        }).orElse(ResponseEntity.notFound().build());
    }
    // ✅ DELETE – Delete Student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable Integer id) {

        if (repo.existsById(id)) {
            repo.deleteById(id);
            return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Student not found", HttpStatus.NOT_FOUND);
        }
    }
}