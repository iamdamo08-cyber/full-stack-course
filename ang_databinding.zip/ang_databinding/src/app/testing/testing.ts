import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-testing',
  imports: [FormsModule],
  templateUrl: './testing.html',
  styleUrl: './testing.css',
})
export class Testing {
// Interpolation binding example
name="DAMODHARAN";

// Property binding example
isDisabled=true;

// Event binding example
enableButton(){
  this.isDisabled=false;
}

// Two-way binding example
username='';
showalert(){
  alert("Hello" + this.username);
}
}

