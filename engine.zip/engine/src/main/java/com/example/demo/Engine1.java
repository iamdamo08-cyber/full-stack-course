package com.example.demo;
import org.springframework.stereotype.Component;
@Component

public class Engine1 {
	public String start()
	{
		return "Engine started";
	}

}
