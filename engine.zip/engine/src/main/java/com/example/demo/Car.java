package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Car {
	public Engine1 engine;
	public Car(Engine1 engine) {
	this.engine= engine;
}
public String drive1() {
	return engine.start();
}

}