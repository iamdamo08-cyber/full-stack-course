package com.example.demo;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CarController {
	private Car car1 ;
	
	public CarController(Car car1) {
		this.car1=car1;
	
	                               }
	@GetMapping("/drive")
	public String drivecar()
	{
		return car1.drive1();
	}

}
