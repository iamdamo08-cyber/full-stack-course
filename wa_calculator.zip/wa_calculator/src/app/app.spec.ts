// Tells TypeScript that angular is loaded globally via the browser
declare var angular: any; 

const app = angular.module('calcApp', []);

app.controller('CalcController', ['$scope', function($scope: any) {
    // Initializing the Model
    $scope.num1 = 0;
    $scope.num2 = 0;
    $scope.result = null;

    // Function to perform arithmetic operations
    $scope.calculate = function(operator: string): void {
        const a = Number($scope.num1);
        const b = Number($scope.num2);

        if (operator === '+') {
            $scope.result = a + b;
        } else if (operator === '-') {
            $scope.result = a - b;
        }
    };
}]);