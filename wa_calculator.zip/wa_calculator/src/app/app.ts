// Fix TS2304: Declare angular so TypeScript knows it exists globally
declare var angular: any;

// Fix TS2307: Exporting 'app' makes it a module that other files can find
export const app = angular.module('calcApp', []);

// Fix TS7006: Add ': any' to parameters to stop implicit 'any' errors
app.controller('CalcController', ['$scope', function($scope: any) {
    $scope.num1 = 0;
    $scope.num2 = 0;
    $scope.result = null;

    $scope.calculate = function(operator: any) {
        const a = Number($scope.num1);
        const b = Number($scope.num2);

        if (operator === '+') {
            $scope.result = a + b;
        } else if (operator === '-') {
            $scope.result = a - b;
        }
    };
}]);