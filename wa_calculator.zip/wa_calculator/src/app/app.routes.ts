import { Routes } from '@angular/router';
import { app } from './app';
export const routes: Routes = [];
// Define the AngularJS Module
var app = angular.module('calcApp', []);

// Define the Controller to handle logic
app.controller('CalcController', function($scope) {
    $scope.num1 = 0;
    $scope.num2 = 0;
    $scope.result = null;

    // Function to perform arithmetic operations
    $scope.calculate = function(operator) {
        if (operator === '+') {
            $scope.result = $scope.num1 + $scope.num2;
        } else if (operator === '-') {
            $scope.result = $scope.num1 - $scope.num2;
        }
        // The result is sent back to the view automatically
    };
});