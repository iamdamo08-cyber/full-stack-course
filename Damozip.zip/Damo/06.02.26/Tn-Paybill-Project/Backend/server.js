// server.js
// Simple backend for login (Node.js + Express)

const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Dummy users (rough data)
const users = [
    { userType: "Employee", userId: "emp001", password: "1234" },
    { userType: "DDO", userId: "ddo001", password: "abcd" },
    { userType: "Officer", userId: "off001", password: "admin" }
];

// Login API
app.post("/login", (req, res) => {
    const { userType, userId, password } = req.body;

    const user = users.find(
        u =>
            u.userType === userType &&
            u.userId === userId &&
            u.password === password
    );

    if (user) {
        res.json({ success: true, message: "Login Successful ✅" });
    } else {
        res.json({ success: false, message: "Invalid Credentials ❌" });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// ---------- END OF server.js ----------
