
const form = document.getElementById("loginForm");

form.addEventListener("submit", function(event) {
 
    document.getElementById("userError").innerText = "";
    document.getElementById("passError").innerText = "";

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    
    let isValid = true;


    const userRegex = /^[a-zA-Z0-9]+$/; 
    if (username === "" || username.length < 5 || !userRegex.test(username)) {
        document.getElementById("userError").innerText = "Invalid Username (Min 5 chars, alphanumeric only).";
        isValid = false;
    }

  
    const passRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/; 
    if (password === "" || password.length < 8 || !passRegex.test(password)) {
        document.getElementById("passError").innerText = "Invalid Password (Min 8 chars, must include Upper, Lower, and Number).";
        isValid = false;
    }

   
    if (!isValid) {
        event.preventDefault(); 
    } else {
        alert("Form submitted successfully!");
    }
});