import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AppComponent } from './app';

describe('AppComponent', () => {
  let fixture: ComponentFixture<AppComponent>;
  let app: AppComponent;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppComponent]
    });
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.componentInstance;
  });

  it('should create the app', () => {
    expect(app).toBeTruthy();
  });

  it('should add numbers to display when press() is called', () => {
    app.press('1');
    app.press('2');
    expect(app.display).toBe('12');
  });

  it('should calculate the expression when calculate() is called', () => {
    app.press('1');
    app.press('+');
    app.press('2');
    app.calculate();
    expect(app.display).toBe('3');
  });

  it('should clear the display when clear() is called', () => {
    app.press('1');
    app.clear();
    expect(app.display).toBe('');
  });

  it('should show error when there is an invalid expression', () => {
    app.press('1');
    app.press('+');
    app.press('/');
    app.calculate();
    expect(app.display).toBe('Error');
  });
});
