import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  styleUrls: ['./app.css'],
  standalone: true,
  imports: [CommonModule]
})
export class AppComponent {
  display: string = '';

  press(value: string) {
    this.display += value;
  }

  clear() {
    this.display = '';
  }

  calculate() {
    try {
      // Using Function constructor instead of eval for better security
      const result = new Function('return ' + this.display)();
      this.display = result.toString();
    } catch {
      this.display = 'Error';
    }
  }
}
