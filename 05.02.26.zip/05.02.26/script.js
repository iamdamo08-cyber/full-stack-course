    function validateform() {
        var username=document.getElementById("username").value;
        var password=document.getElementById("password").value;
        if(username==""){
            alert("Please fill in username");
            return false;               
                        }

        
        if(password==""){
            alert("Please fill in password");
            return false;               
                        }
                          }