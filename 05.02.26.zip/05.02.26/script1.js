function checkLogin() {
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        if(username==""){
            alert("Please fill in username");
            return false;               
                        }

        
        if(password==""){
            alert("Please fill in password");
            return false;               
                        }
        if (username== "abc" && password== "123") {
             alert("You have entered correctly");

             window.location.href = "https://eservices.tnpolice.gov.in";
             return false;
             }
             else {    
                alert("Incorrect username or password");
    
             }         }
de