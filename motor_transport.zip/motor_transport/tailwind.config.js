module.exports = {
  content: [
    "./src/**/*.{html,ts,scss}"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1e2a47',
          light: '#2d3a5a',
          dark: '#16203a'
        },
        accent: {
          DEFAULT: '#4f8cff',
        },
        glass: 'rgba(255,255,255,0.7)',
        background: '#f4f6f9'
      },
      fontFamily: {
        sans: ['Poppins', 'Inter', 'sans-serif']
      },
      borderRadius: {
        card: '16px'
      },
      boxShadow: {
        glass: '0 8px 32px 0 rgba(31, 38, 135, 0.18)'
      }
    }
  },
  plugins: [],
}
