// Driver model interface
export interface Driver {
  id: string;
  name: string;
  policeId: string;
  designation: string;
  licenseNumber: string;
  licenseExpiryDate: string; // ISO date string
  contactNumber: string;
}
