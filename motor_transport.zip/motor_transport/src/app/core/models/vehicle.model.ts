// Vehicle model interface
export interface Vehicle {
  id: string;
  registrationNumber: string;
  manufacturingDate: string; // ISO date string
  make: string;
  model: string;
  insuranceDetails: string;
  lastServicedDate: string; // ISO date string
  nextServiceDate: string; // ISO date string
  currentLocation: {
    latitude: number;
    longitude: number;
  };
  assignedDriverId?: string; // Reference to Driver
  type: 'Car' | 'Bus' | 'Motorcycle' | 'Lorry';
}
