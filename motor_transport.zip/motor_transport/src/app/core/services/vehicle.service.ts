import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Vehicle } from '../models/vehicle.model';

// Mock vehicle data
const VEHICLES: Vehicle[] = [
  {
    id: '1',
    registrationNumber: 'POL-001',
    manufacturingDate: '2020-01-15',
    make: 'Toyota',
    model: 'Corolla',
    insuranceDetails: 'Valid till 2026-03-01',
    lastServicedDate: '2025-12-01',
    nextServiceDate: '2026-06-01',
    currentLocation: { latitude: 6.5244, longitude: 3.3792 },
    assignedDriverId: 'd1',
    type: 'Car'
  },
  {
    id: '2',
    registrationNumber: 'POL-002',
    manufacturingDate: '2019-07-20',
    make: 'Honda',
    model: 'Civic',
    insuranceDetails: 'Valid till 2026-04-15',
    lastServicedDate: '2025-11-10',
    nextServiceDate: '2026-05-10',
    currentLocation: { latitude: 6.4654, longitude: 3.4064 },
    assignedDriverId: 'd2',
    type: 'Car'
  },
  {
    id: '3',
    registrationNumber: 'POL-003',
    manufacturingDate: '2018-03-10',
    make: 'Mercedes',
    model: 'Sprinter',
    insuranceDetails: 'Valid till 2026-02-28',
    lastServicedDate: '2025-10-05',
    nextServiceDate: '2026-04-05',
    currentLocation: { latitude: 6.5244, longitude: 3.3792 },
    assignedDriverId: 'd3',
    type: 'Bus'
  },
  {
    id: '4',
    registrationNumber: 'POL-004',
    manufacturingDate: '2021-09-12',
    make: 'Yamaha',
    model: 'FZ',
    insuranceDetails: 'Valid till 2026-05-20',
    lastServicedDate: '2025-12-20',
    nextServiceDate: '2026-06-20',
    currentLocation: { latitude: 6.6000, longitude: 3.3500 },
    assignedDriverId: 'd4',
    type: 'Motorcycle'
  },
  {
    id: '5',
    registrationNumber: 'POL-005',
    manufacturingDate: '2017-11-30',
    make: 'MAN',
    model: 'TGS',
    insuranceDetails: 'Valid till 2026-03-15',
    lastServicedDate: '2025-09-15',
    nextServiceDate: '2026-03-15',
    currentLocation: { latitude: 6.5100, longitude: 3.3800 },
    assignedDriverId: 'd5',
    type: 'Lorry'
  },
  {
    id: '6',
    registrationNumber: 'POL-006',
    manufacturingDate: '2022-02-18',
    make: 'Toyota',
    model: 'Hiace',
    insuranceDetails: 'Valid till 2026-07-01',
    lastServicedDate: '2025-12-30',
    nextServiceDate: '2026-07-01',
    currentLocation: { latitude: 6.5200, longitude: 3.4000 },
    assignedDriverId: 'd1',
    type: 'Bus'
  },
  {
    id: '7',
    registrationNumber: 'POL-007',
    manufacturingDate: '2023-05-05',
    make: 'Suzuki',
    model: 'GSX',
    insuranceDetails: 'Valid till 2026-08-10',
    lastServicedDate: '2026-01-10',
    nextServiceDate: '2026-08-10',
    currentLocation: { latitude: 6.5300, longitude: 3.4100 },
    assignedDriverId: 'd2',
    type: 'Motorcycle'
  },
  {
    id: '8',
    registrationNumber: 'POL-008',
    manufacturingDate: '2016-08-22',
    make: 'Iveco',
    model: 'Eurocargo',
    insuranceDetails: 'Valid till 2026-02-20',
    lastServicedDate: '2025-08-20',
    nextServiceDate: '2026-02-20',
    currentLocation: { latitude: 6.5400, longitude: 3.4200 },
    assignedDriverId: 'd3',
    type: 'Lorry'
  }
];

@Injectable({ providedIn: 'root' })
export class VehicleService {
  private vehiclesSubject = new BehaviorSubject<Vehicle[]>(VEHICLES);
  vehicles$ = this.vehiclesSubject.asObservable();

  getVehicles() {
    return this.vehiclesSubject.value;
  }

  addVehicle(vehicle: Vehicle) {
    this.vehiclesSubject.next([...this.vehiclesSubject.value, vehicle]);
  }

  updateVehicle(updated: Vehicle) {
    this.vehiclesSubject.next(
      this.vehiclesSubject.value.map(v => v.id === updated.id ? updated : v)
    );
  }

  deleteVehicle(id: string) {
    this.vehiclesSubject.next(
      this.vehiclesSubject.value.filter(v => v.id !== id)
    );
  }

  getVehicleById(id: string) {
    return this.vehiclesSubject.value.find(v => v.id === id);
  }
}
