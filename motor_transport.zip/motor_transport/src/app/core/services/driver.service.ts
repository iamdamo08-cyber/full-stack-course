import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Driver } from '../models/driver.model';

// Mock driver data
const DRIVERS: Driver[] = [
  {
    id: 'd1',
    name: 'John Doe',
    policeId: 'PID123',
    designation: 'Sergeant',
    licenseNumber: 'LIC-001',
    licenseExpiryDate: '2027-05-10',
    contactNumber: '08012345678'
  },
  // ...add more mock drivers
];

@Injectable({ providedIn: 'root' })
export class DriverService {
  private driversSubject = new BehaviorSubject<Driver[]>(DRIVERS);
  drivers$ = this.driversSubject.asObservable();

  getDrivers() {
    return this.driversSubject.value;
  }

  addDriver(driver: Driver) {
    this.driversSubject.next([...this.driversSubject.value, driver]);
  }

  updateDriver(updated: Driver) {
    this.driversSubject.next(
      this.driversSubject.value.map(d => d.id === updated.id ? updated : d)
    );
  }

  deleteDriver(id: string) {
    this.driversSubject.next(
      this.driversSubject.value.filter(d => d.id !== id)
    );
  }

  getDriverById(id: string) {
    return this.driversSubject.value.find(d => d.id === id);
  }
}
