import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../core/services/vehicle.service';
import { DriverService } from '../../core/services/driver.service';
import { Vehicle } from '../../core/models/vehicle.model';
import { Router, RouterModule } from '@angular/router';
import { CardComponent } from '../../shared/components/card.component';
import { ButtonComponent } from '../../shared/components/button.component';
import { BadgeComponent } from '../../shared/components/badge.component';
import { ToastComponent } from '../../shared/components/toast.component';
import { LoaderComponent } from '../../shared/components/loader.component';

@Component({
  selector: 'app-vehicle-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, CardComponent, ButtonComponent, BadgeComponent, ToastComponent, LoaderComponent],
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {
  vehicles: Vehicle[] = [];
  filteredVehicles: Vehicle[] = [];
  vehicleTypes: string[] = ['All', 'Car', 'Bus', 'Motorcycle', 'Lorry'];
  selectedType: string = 'All';
  searchTerm: string = '';
  cardView: boolean = false;
  drivers: any[] = [];
  loading = false;
  toast = signal<{ show: boolean; type: 'success' | 'error' | 'info'; message: string }>({ show: false, type: 'success', message: '' });

  constructor(private vehicleService: VehicleService, private driverService: DriverService, private router: Router) {}

  ngOnInit() {
    this.loading = true;
    setTimeout(() => {
      this.vehicles = this.vehicleService.getVehicles();
      this.drivers = this.driverService.getDrivers();
      this.applyFilter();
      this.loading = false;
    }, 700);
  }

  applyFilter() {
    let filtered = this.vehicles;
    if (this.selectedType !== 'All') {
      filtered = filtered.filter(v => v.type === this.selectedType);
    }
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.trim().toLowerCase();
      filtered = filtered.filter(v =>
        v.registrationNumber.toLowerCase().includes(term) ||
        v.make.toLowerCase().includes(term) ||
        v.model.toLowerCase().includes(term)
      );
    }
    this.filteredVehicles = filtered;
  }

  toggleView() {
    this.cardView = !this.cardView;
  }

  viewDetails(vehicle: Vehicle) {
    this.router.navigate(['/vehicles', vehicle.id]);
  }

  getDriverName(driverId?: string): string {
    if (!driverId) return 'Unassigned';
    const driver = this.drivers.find(d => d.id === driverId);
    return driver ? driver.name : 'Unassigned';
  }

  getStatus(vehicle: Vehicle): string {
    const today = new Date();
    const nextService = new Date(vehicle.nextServiceDate);
    const insuranceMatch = vehicle.insuranceDetails.match(/\d{4}-\d{2}-\d{2}/);
    let insuranceExpiring = false;
    if (insuranceMatch) {
      const expDate = new Date(insuranceMatch[0]);
      insuranceExpiring = (expDate.getTime() - today.getTime()) / (1000 * 3600 * 24) <= 30;
    }
    if (insuranceExpiring) return 'Insurance Due';
    if (nextService <= today) return 'In Service';
    return 'Active';
  }

  getStatusType(vehicle: Vehicle): 'success' | 'warning' | 'error' | 'info' {
    const status = this.getStatus(vehicle);
    if (status === 'Active') return 'success';
    if (status === 'In Service') return 'warning';
    if (status === 'Insurance Due') return 'error';
    return 'info';
  }
}
