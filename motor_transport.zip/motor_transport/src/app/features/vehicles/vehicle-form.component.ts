import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicleService } from '../../core/services/vehicle.service';
import { DriverService } from '../../core/services/driver.service';
import { Vehicle } from '../../core/models/vehicle.model';
import { Driver } from '../../core/models/driver.model';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from '../../shared/components/toast.component';
import { LoaderComponent } from '../../shared/components/loader.component';
import { CardComponent } from '../../shared/components/card.component';
import { ButtonComponent } from '../../shared/components/button.component';

// Simple unique ID generator for demo (not for production)
function uuidv4() {
  return 'v-' + Math.random().toString(36).substr(2, 9);
}

@Component({
  selector: 'app-vehicle-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, ToastComponent, LoaderComponent, CardComponent, ButtonComponent],
  templateUrl: './vehicle-form.component.html',
  styleUrls: ['./vehicle-form.component.css']
})
export class VehicleFormComponent implements OnInit {
  vehicle: Vehicle = {
    id: '',
    registrationNumber: '',
    manufacturingDate: '',
    make: '',
    model: '',
    insuranceDetails: '',
    lastServicedDate: '',
    nextServiceDate: '',
    currentLocation: { latitude: 0, longitude: 0 },
    assignedDriverId: undefined,
    type: 'Car'
  };
  drivers: Driver[] = [];
  isEdit = false;
  loading = false;
  toast = signal<{ show: boolean; type: 'success' | 'error' | 'info'; message: string }>({ show: false, type: 'success', message: '' });

  constructor(
    private vehicleService: VehicleService,
    private driverService: DriverService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.drivers = this.driverService.getDrivers();
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      const found = this.vehicleService.getVehicleById(id);
      if (found) {
        this.vehicle = { ...found };
        this.isEdit = true;
      }
    }
  }

  saveVehicle() {
    this.loading = true;
    setTimeout(() => {
      if (this.isEdit) {
        this.vehicleService.updateVehicle(this.vehicle);
      } else {
        this.vehicle.id = uuidv4();
        this.vehicleService.addVehicle(this.vehicle);
      }
      this.loading = false;
      this.toast.set({ show: true, type: 'success', message: this.isEdit ? 'Vehicle updated successfully!' : 'Vehicle added successfully!' });
      setTimeout(() => {
        this.toast.set({ ...this.toast(), show: false });
        this.router.navigate(['/vehicles']);
      }, 1200);
    }, 900);
  }
}
