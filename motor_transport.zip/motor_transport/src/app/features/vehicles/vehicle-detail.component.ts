import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { VehicleService } from '../../core/services/vehicle.service';
import { DriverService } from '../../core/services/driver.service';
import { Vehicle } from '../../core/models/vehicle.model';
import { Driver } from '../../core/models/driver.model';

@Component({
  selector: 'app-vehicle-detail',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './vehicle-detail.component.html',
  styleUrls: ['./vehicle-detail.component.css']
})
export class VehicleDetailComponent implements OnInit {
  vehicle?: Vehicle;
  driver?: Driver;

  constructor(
    private route: ActivatedRoute,
    private vehicleService: VehicleService,
    private driverService: DriverService,
    private router: Router
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.vehicle = this.vehicleService.getVehicleById(id);
      if (this.vehicle?.assignedDriverId) {
        this.driver = this.driverService.getDriverById(this.vehicle.assignedDriverId);
      }
    }
  }

  goBack() {
    this.router.navigate(['/vehicles']);
  }
}
