import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VehicleService } from '../../core/services/vehicle.service';
import { DriverService } from '../../core/services/driver.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  totalVehicles = 0;
  totalDrivers = 0;
  vehicleTypeCount: Record<string, number> = {};
  dueForService = 0;
  insuranceExpiringSoon = 0;

  constructor(
    private vehicleService: VehicleService,
    private driverService: DriverService
  ) {
    const vehicles = this.vehicleService.getVehicles();
    const drivers = this.driverService.getDrivers();
    this.totalVehicles = vehicles.length;
    this.totalDrivers = drivers.length;
    this.vehicleTypeCount = vehicles.reduce((acc, v) => {
      acc[v.type] = (acc[v.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    const today = new Date();
    this.dueForService = vehicles.filter(v => new Date(v.nextServiceDate) <= today).length;
    this.insuranceExpiringSoon = vehicles.filter(v => {
      // Extract date from insuranceDetails string (mock logic)
      const match = v.insuranceDetails.match(/\d{4}-\d{2}-\d{2}/);
      if (!match) return false;
      const expDate = new Date(match[0]);
      const diff = (expDate.getTime() - today.getTime()) / (1000 * 3600 * 24);
      return diff <= 30;
    }).length;
  }
}
