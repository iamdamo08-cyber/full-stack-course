import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DriverService } from '../../core/services/driver.service';
import { Driver } from '../../core/models/driver.model';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ToastComponent } from '../../shared/components/toast.component';
import { LoaderComponent } from '../../shared/components/loader.component';
import { CardComponent } from '../../shared/components/card.component';
import { ButtonComponent } from '../../shared/components/button.component';

// Simple unique ID generator for demo (not for production)
function uuidv4() {
  return 'd-' + Math.random().toString(36).substr(2, 9);
}

@Component({
  selector: 'app-driver-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, ToastComponent, LoaderComponent, CardComponent, ButtonComponent],
  templateUrl: './driver-form.component.html',
  styleUrls: ['./driver-form.component.css']
})
export class DriverFormComponent implements OnInit {
  driver: Driver = {
    id: '',
    name: '',
    policeId: '',
    designation: '',
    licenseNumber: '',
    licenseExpiryDate: '',
    contactNumber: ''
  };
  isEdit = false;
  loading = false;
  toast = signal<{ show: boolean; type: 'success' | 'error' | 'info'; message: string }>({ show: false, type: 'success', message: '' });

  constructor(
    private driverService: DriverService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      const found = this.driverService.getDriverById(id);
      if (found) {
        this.driver = { ...found };
        this.isEdit = true;
      }
    }
  }

  saveDriver() {
    this.loading = true;
    setTimeout(() => {
      if (this.isEdit) {
        this.driverService.updateDriver(this.driver);
      } else {
        this.driver.id = uuidv4();
        this.driverService.addDriver(this.driver);
      }
      this.loading = false;
      this.toast.set({ show: true, type: 'success', message: this.isEdit ? 'Driver updated successfully!' : 'Driver added successfully!' });
      setTimeout(() => {
        this.toast.set({ ...this.toast(), show: false });
        this.router.navigate(['/drivers']);
      }, 1200);
    }, 900);
  }
}
