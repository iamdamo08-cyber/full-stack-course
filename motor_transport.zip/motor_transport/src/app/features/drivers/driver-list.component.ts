import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DriverService } from '../../core/services/driver.service';
import { Driver } from '../../core/models/driver.model';
import { Router, RouterModule } from '@angular/router';
import { ToastComponent } from '../../shared/components/toast.component';
import { LoaderComponent } from '../../shared/components/loader.component';
import { ButtonComponent } from '../../shared/components/button.component';

@Component({
  selector: 'app-driver-list',
  standalone: true,
  imports: [CommonModule, RouterModule, ToastComponent, LoaderComponent, ButtonComponent],
  templateUrl: './driver-list.component.html',
  styleUrls: ['./driver-list.component.css']
})
export class DriverListComponent implements OnInit {
  drivers: Driver[] = [];
  loading = false;
  toast = signal<{ show: boolean; type: 'success' | 'error' | 'info'; message: string }>({ show: false, type: 'success', message: '' });

  constructor(private driverService: DriverService, private router: Router) {}

  ngOnInit() {
    this.loading = true;
    setTimeout(() => {
      this.drivers = this.driverService.getDrivers();
      this.loading = false;
    }, 700);
  }

  editDriver(driver: Driver) {
    this.toast.set({ show: true, type: 'info', message: 'Opening driver for edit...' });
    setTimeout(() => {
      this.toast.set({ ...this.toast(), show: false });
      this.router.navigate(['/drivers/edit', driver.id]);
    }, 700);
  }

  addDriver() {
    this.toast.set({ show: true, type: 'info', message: 'Opening add driver form...' });
    setTimeout(() => {
      this.toast.set({ ...this.toast(), show: false });
      this.router.navigate(['/drivers/add']);
    }, 700);
  }
}
