import { Routes } from '@angular/router';

import { DashboardComponent } from './features/dashboard/dashboard.component';
import { VehicleListComponent } from './features/vehicles/vehicle-list.component';
import { VehicleDetailComponent } from './features/vehicles/vehicle-detail.component';
import { VehicleFormComponent } from './features/vehicles/vehicle-form.component';
import { DriverListComponent } from './features/drivers/driver-list.component';
import { DriverFormComponent } from './features/drivers/driver-form.component';

export const routes: Routes = [
	{ path: '', redirectTo: 'dashboard', pathMatch: 'full' },
	{ path: 'dashboard', component: DashboardComponent },
	{ path: 'vehicles', component: VehicleListComponent },
	{ path: 'vehicles/add', component: VehicleFormComponent },
	{ path: 'vehicles/edit/:id', component: VehicleFormComponent },
	{ path: 'vehicles/:id', component: VehicleDetailComponent },
	{ path: 'drivers', component: DriverListComponent },
	{ path: 'drivers/add', component: DriverFormComponent },
	{ path: 'drivers/edit/:id', component: DriverFormComponent },
	{ path: '**', redirectTo: 'dashboard' }
];
