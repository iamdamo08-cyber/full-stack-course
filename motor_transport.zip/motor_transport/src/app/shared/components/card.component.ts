import { Component, Input } from '@angular/core';

@Component({
  selector: 'ui-card',
  standalone: true,
  template: `<div class="ui-card" [ngClass]="extraClass"><ng-content></ng-content></div>`,
  styleUrls: ['./card.component.scss']
})
export class CardComponent {
  @Input() extraClass = '';
}
