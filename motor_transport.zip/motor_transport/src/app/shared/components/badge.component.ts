import { Component, Input } from '@angular/core';

@Component({
  selector: 'ui-badge',
  standalone: true,
  template: `<span class="ui-badge" [ngClass]="type"><ng-content></ng-content></span>`,
  styleUrls: ['./badge.component.scss']
})
export class BadgeComponent {
  @Input() type: 'success' | 'warning' | 'error' | 'info' = 'info';
}
