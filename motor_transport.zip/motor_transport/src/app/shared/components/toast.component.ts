import { Component, Input } from '@angular/core';

@Component({
  selector: 'ui-toast',
  standalone: true,
  template: `
    <div class="ui-toast" [ngClass]="type" *ngIf="show">
      <span class="icon">{{ icon }}</span>
      <span class="message"><ng-content></ng-content></span>
    </div>
  `,
  styleUrls: ['./toast.component.scss']
})
export class ToastComponent {
  @Input() type: 'success' | 'error' | 'info' = 'info';
  @Input() show = false;
  get icon() {
    switch (this.type) {
      case 'success': return '✔️';
      case 'error': return '❌';
      case 'info':
      default: return 'ℹ️';
    }
  }
}
