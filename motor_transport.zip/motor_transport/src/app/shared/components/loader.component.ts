import { Component, Input } from '@angular/core';

@Component({
  selector: 'ui-loader',
  standalone: true,
  template: `
    <div class="ui-loader">
      <span class="dot"></span>
      <span class="dot"></span>
      <span class="dot"></span>
    </div>
  `,
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent {}
