import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-4HCLV4A5.js";
import "./chunk-VCOISGZY.js";
import "./chunk-JF7UDAU2.js";
import "./chunk-OLMCMWW4.js";
import "./chunk-FAI4WHEZ.js";
import "./chunk-6DU2HRTW.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
