import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-WTAMX5GB.js";
import "./chunk-FAI4WHEZ.js";
import "./chunk-6DU2HRTW.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
