import { Routes } from '@angular/router';
import { LayoutComponent } from './components/layout/layout';
import { Home } from './pages/home/home';
import { Dashboard } from './pages/dashboard/dashboard';
import { EventsComponent } from './pages/events/events';
import { CreateEventComponent } from './pages/create-event/create-event';
import { FoodComponent } from './pages/food/food';
import { DecorationsComponent } from './pages/decorations/decorations';
import { CakesComponent } from './pages/cakes/cakes';
import { VendorsComponent } from './pages/vendors/vendors';
import { GalleryComponent } from './pages/gallery/gallery';
import { ReportsComponent } from './pages/reports/reports';
import { SettingsComponent } from './pages/settings/settings';

export const routes: Routes = [
  { path: '', component: Home },
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: 'dashboard', component: Dashboard },
      { path: 'events', component: EventsComponent },
      { path: 'create-event', component: CreateEventComponent },
      { path: 'food', component: FoodComponent },
      { path: 'decorations', component: DecorationsComponent },
      { path: 'cakes', component: CakesComponent },
      { path: 'vendors', component: VendorsComponent },
      { path: 'gallery', component: GalleryComponent },
      { path: 'reports', component: ReportsComponent },
      { path: 'settings', component: SettingsComponent }
    ]
  }
];
