import { Component, inject, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { EventService } from '../../services/event';
import { Event } from '../../models/event.model';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.html',
  styleUrls: ['./create-event.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatButtonModule, MatInputModule, MatSelectModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateEventComponent {
  private eventService = inject(EventService);
  private fb = inject(FormBuilder);
  
  isSubmitting = signal(false);
  successMessage = signal('');

  form = this.fb.group({
    name: ['', Validators.required],
    type: ['Wedding', Validators.required],
    date: ['', Validators.required],
    location: ['', Validators.required],
    clientName: ['', Validators.required],
    budget: [0, [Validators.required, Validators.min(1000)]],
    description: ['', Validators.required]
  });

  createEvent(): void {
    if (this.form.invalid) {
      alert('Please fill in all required fields');
      return;
    }

    this.isSubmitting.set(true);
    
    const newEvent: Omit<Event, 'id' | 'createdAt' | 'updatedAt'> = {
      name: this.form.value.name || '',
      type: this.form.value.type as any,
      status: 'Upcoming',
      date: new Date(this.form.value.date || ''),
      location: this.form.value.location || '',
      clientId: 'c' + Date.now(),
      clientName: this.form.value.clientName || '',
      budget: this.form.value.budget || 0,
      description: this.form.value.description || '',
      vendorIds: [],
      foodItems: [],
      decorationThemeId: undefined,
      cakeId: undefined,
      spentBudget: 0
    };

    this.eventService.addEvent(newEvent);
    this.successMessage.set('Event created successfully!');
    this.form.reset({ type: 'Wedding' });
    
    setTimeout(() => {
      this.isSubmitting.set(false);
      this.successMessage.set('');
    }, 2000);
  }
}
