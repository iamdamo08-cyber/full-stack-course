import { Component, ChangeDetectionStrategy, inject, computed, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EventService } from '../../services/event';
import { FoodService } from '../../services/food';
import { DecorationService } from '../../services/decoration';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>📊 Reports & Analytics</h1>
        <p>Business intelligence and event analytics</p>
      </div>

      <!-- Key Metrics -->
      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-icon blue">
            <mat-icon>event</mat-icon>
          </div>
          <div class="metric-content">
            <p>Total Events</p>
            <h3>{{ eventService.totalEvents() }}</h3>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon green">
            <mat-icon>check_circle</mat-icon>
          </div>
          <div class="metric-content">
            <p>Completed</p>
            <h3>{{ eventService.completedEvents() }}</h3>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon purple">
            <mat-icon>calendar_today</mat-icon>
          </div>
          <div class="metric-content">
            <p>Upcoming</p>
            <h3>{{ eventService.upcomingEvents() }}</h3>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon orange">
            <mat-icon>trending_up</mat-icon>
          </div>
          <div class="metric-content">
            <p>Total Revenue</p>
            <h3>₹{{ (eventService.totalRevenue() / 100000).toFixed(1) }}L</h3>
          </div>
        </div>
      </div>

      <!-- Additional Analytics -->
      <div class="analytics-section">
        <h2>Services Summary</h2>
        <div class="summary-grid">
          <div class="summary-card">
            <mat-icon>restaurant</mat-icon>
            <p>Food Items</p>
            <h3>{{ foodService.foodItems().length }}</h3>
          </div>
          
          <div class="summary-card">
            <mat-icon>palette</mat-icon>
            <p>Decoration Themes</p>
            <h3>{{ decorationService.decorationThemes().length }}</h3>
          </div>
        </div>
      </div>

      <!-- Export Section -->
      <div class="export-section">
        <h2>Export Reports</h2>
        <div class="button-group">
          <button class="btn-export">📄 Export as PDF</button>
          <button class="btn-export">📊 Export as Excel</button>
          <button class="btn-export">📧 Email Report</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    
    .metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 40px; }
    .metric-card { background: white; border-radius: 12px; padding: 20px; display: flex; align-items: center; gap: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .metric-card:hover { transform: translateY(-4px); box-shadow: 0 8px 16px rgba(0,0,0,0.15); }
    
    .metric-icon { width: 56px; height: 56px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; }
    .metric-icon.blue { background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%); }
    .metric-icon.green { background: linear-gradient(135deg, #48bb78 0%, #38a169 100%); }
    .metric-icon.purple { background: linear-gradient(135deg, #9f7aea 0%, #805ad5 100%); }
    .metric-icon.orange { background: linear-gradient(135deg, #ed8936 0%, #d2845e 100%); }
    
    .metric-content p { color: #718096; font-size: 13px; margin: 0 0 4px; font-weight: 500; }
    .metric-content h3 { color: #1a202c; font-size: 24px; margin: 0; font-weight: 700; }
    
    .analytics-section { margin-bottom: 40px; }
    .analytics-section h2 { font-size: 20px; font-weight: 600; color: #1a202c; margin: 0 0 20px; }
    
    .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
    .summary-card { background: white; border-radius: 12px; padding: 20px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .summary-card:hover { transform: translateY(-4px); }
    .summary-card mat-icon { font-size: 40px; width: 40px; height: 40px; margin: 0 auto 12px; color: #667eea; }
    .summary-card p { color: #718096; margin: 0 0 8px; font-size: 14px; }
    .summary-card h3 { color: #1a202c; font-size: 28px; margin: 0; font-weight: 700; }
    
    .export-section { background: white; border-radius: 12px; padding: 28px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .export-section h2 { font-size: 20px; font-weight: 600; color: #1a202c; margin: 0 0 20px; }
    
    .button-group { display: flex; gap: 12px; flex-wrap: wrap; }
    .btn-export { padding: 12px 24px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; transition: all 0.3s; }
    .btn-export:hover { transform: translateY(-2px); box-shadow: 0 8px 16px rgba(102, 126, 234, 0.3); }
    
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .metric-card,
    :host-context(.dark-mode) .summary-card,
    :host-context(.dark-mode) .export-section { background: #2d3748; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ReportsComponent {
  eventService = inject(EventService);
  foodService = inject(FoodService);
  decorationService = inject(DecorationService);
}
