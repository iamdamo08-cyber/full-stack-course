import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { GalleryService } from '../../services/gallery';

@Component({
  selector: 'app-gallery',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>📷 Gallery - Past Events</h1>
        <p>Showcase of our completed events</p>
      </div>

      <div class="gallery-grid">
        @for (item of galleryService.galleryItems(); track item.id) {
          <div class="gallery-card">
            <div class="image-container">
              <div class="main-image" [style.backgroundImage]="'url(' + item.images[0] + ')'"></div>
              <div class="overlay">
                <div class="overlay-content">
                  <h3>{{ item.eventName }}</h3>
                  <p class="by">{{ item.clientName }}</p>
                </div>
              </div>
            </div>

            <div class="gallery-info">
              <p class="desc">{{ item.description }}</p>
              <div class="budget-row">
                <span>Budget: ₹{{ item.budget | number }}</span>
                <span>Spent: ₹{{ item.spentBudget | number }}</span>
              </div>
              <p class="date">{{ item.completedAt | date: 'dd MMM, yyyy' }}</p>
            </div>
          </div>
        }
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    .gallery-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
    .gallery-card { border-radius: 12px; overflow: hidden; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: all 0.3s; }
    .gallery-card:hover { transform: translateY(-8px); box-shadow: 0 12px 24px rgba(0,0,0,0.15); }
    .image-container { position: relative; width: 100%; height: 240px; overflow: hidden; }
    .main-image { width: 100%; height: 100%; background-size: cover; background-position: center; }
    .overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(135deg, rgba(0,0,0,0.3) 0%, rgba(0,0,0,0.6) 100%); display: flex; align-items: flex-end; padding: 16px; color: white; opacity: 0; transition: opacity 0.3s; }
    .gallery-card:hover .overlay { opacity: 1; }
    .overlay-content h3 { font-size: 18px; font-weight: 700; margin: 0 0 4px; }
    .overlay-content .by { font-size: 13px; margin: 0; }
    .gallery-info { padding: 16px; }
    .desc { font-size: 13px; color: #718096; margin: 0 0 12px; }
    .budget-row { display: flex; justify-content: space-between; font-size: 12px; font-weight: 600; color: #667eea; margin-bottom: 8px; }
    .date { font-size: 12px; color: #a0a0c0; margin: 0; }
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .gallery-card { background: #2d3748; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GalleryComponent {
  galleryService = inject(GalleryService);
}
