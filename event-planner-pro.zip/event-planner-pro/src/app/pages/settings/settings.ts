import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ThemeService } from '../../services/theme';

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatSlideToggleModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>⚙️ Settings</h1>
        <p>Customize your EventPro experience</p>
      </div>

      <div class="settings-card">
        <h2>Appearance</h2>
        
        <div class="setting-item">
          <div class="setting-info">
            <h3>Dark Mode</h3>
            <p>Enable dark theme for better viewing in low light</p>
          </div>
          <label class="toggle">
            <input 
              type="checkbox" 
              [checked]="themeService.darkMode()"
              (change)="themeService.toggleDarkMode()"
            />
            <span class="slider"></span>
          </label>
        </div>

        <div style="border-top: 1px solid #eee; margin: 16px 0;"></div>

        <div class="setting-item">
          <div class="setting-info">
            <h3>Notifications</h3>
            <p>Receive alerts for upcoming events</p>
          </div>
          <label class="toggle">
            <input type="checkbox" checked />
            <span class="slider"></span>
          </label>
        </div>

        <div style="border-top: 1px solid #eee; margin: 16px 0;"></div>

        <div class="setting-item">
          <div class="setting-info">
            <h3>Email Reminders</h3>
            <p>Get email notifications for important dates</p>
          </div>
          <label class="toggle">
            <input type="checkbox" checked />
            <span class="slider"></span>
          </label>
        </div>
      </div>

      <div class="settings-card">
        <h2>Account</h2>
        
        <div class="setting-item">
          <div class="setting-info">
            <h3>Account Details</h3>
            <p>Manage your profile and login information</p>
          </div>
          <button class="btn-setting">Edit</button>
        </div>

        <div style="border-top: 1px solid #eee; margin: 16px 0;"></div>

        <div class="setting-item">
          <div class="setting-info">
            <h3>Download Data</h3>
            <p>Export all your event data</p>
          </div>
          <button class="btn-setting">Download</button>
        </div>

        <div style="border-top: 1px solid #eee; margin: 16px 0;"></div>

        <div class="setting-item">
          <div class="setting-info">
            <h3>Privacy & Security</h3>
            <p>Manage your privacy settings</p>
          </div>
          <button class="btn-setting">Manage</button>
        </div>
      </div>

      <div class="settings-card danger">
        <h2>Danger Zone</h2>
        <p style="color: #e53e3e; font-size: 14px;">These actions cannot be undone</p>
        
        <div class="setting-item">
          <div class="setting-info">
            <h3>Delete Account</h3>
            <p>Permanently delete your account and all data</p>
          </div>
          <button class="btn-danger">Delete</button>
        </div>
      </div>

      <div class="about-section">
        <h3>About EventPro</h3>
        <p>Version 1.0.0</p>
        <p>© 2025 EventPro. All rights reserved.</p>
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 800px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    
    .settings-card { background: white; border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .settings-card.danger { border-left: 4px solid #e53e3e; }
    .settings-card h2 { font-size: 18px; font-weight: 600; color: #1a202c; margin: 0 0 20px; }
    
    .setting-item { display: flex; justify-content: space-between; align-items: center; padding: 16px 0; }
    .setting-info h3 { font-size: 16px; font-weight: 600; color: #1a202c; margin: 0 0 4px; }
    .setting-info p { color: #718096; font-size: 13px; margin: 0; }
    
    .toggle { display: flex; width: 50px; height: 28px; background: #ccc; border-radius: 14px; cursor: pointer; position: relative; transition: background 0.3s; }
    .toggle input { display: none; }
    .toggle input:checked + .slider { background: #667eea; }
    .toggle input:checked + .slider::after { transform: translateX(22px); }
    .slider { position: absolute; width: 100%; height: 100%; border-radius: 14px; background: #ccc; transition: background 0.3s; }
    .slider::after { content: ''; position: absolute; width: 24px; height: 24px; background: white; border-radius: 50%; top: 2px; left: 2px; transition: transform 0.3s; }
    
    .btn-setting { padding: 8px 16px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; }
    .btn-setting:hover { transform: translateY(-1px); }
    
    .btn-danger { padding: 8px 16px; background: linear-gradient(135deg, #fc8181 0%, #f56565 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; }
    .btn-danger:hover { transform: translateY(-1px); }
    
    .about-section { text-align: center; padding: 32px 0 0; border-top: 1px solid #eee; color: #718096; }
    .about-section h3 { font-size: 14px; font-weight: 600; color: #1a202c; margin: 0 0 8px; }
    .about-section p { margin: 4px 0; font-size: 13px; }
    
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .settings-card { background: #2d3748; }
    :host-context(.dark-mode) .setting-info h3 { color: #f0f4f8; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsComponent {
  themeService = inject(ThemeService);
}
