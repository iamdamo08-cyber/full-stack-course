import { Component, ChangeDetectionStrategy, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { EventService } from '../../services/event';
import { FoodService } from '../../services/food';
import { DecorationService } from '../../services/decoration';
import { VendorService } from '../../services/vendor';
import { MenuRequestService, MenuRequest } from '../../services/menu-request';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule, MatButtonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Dashboard {
  private eventService = inject(EventService);
  private foodService = inject(FoodService);
  private decorationService = inject(DecorationService);
  private vendorService = inject(VendorService);

  private menuRequestService = inject(MenuRequestService);

  totalEvents = this.eventService.totalEvents;
  upcomingEvents = this.eventService.upcomingEvents;
  completedEvents = this.eventService.completedEvents;
  totalRevenue = this.eventService.totalRevenue;
  
  recentEvents = computed(() => 
    this.eventService.events().slice(0, 5)
  );

  stats = computed(() => [
    {
      title: 'Total Events',
      value: this.totalEvents(),
      icon: 'event',
      color: 'gradient-blue',
      percentage: '+12%'
    },
    {
      title: 'Upcoming Events',
      value: this.upcomingEvents(),
      icon: 'calendar_today',
      color: 'gradient-purple',
      percentage: '+8%'
    },
    {
      title: 'Completed Events',
      value: this.completedEvents(),
      icon: 'check_circle',
      color: 'gradient-green',
      percentage: '+25%'
    },
    {
      title: 'Total Revenue',
      value: '₹' + (this.totalRevenue() / 100000).toFixed(1) + 'L',
      icon: 'trending_up',
      color: 'gradient-orange',
      percentage: '+18%'
    }
  ]);

  totalItems = computed(() => ({
    foodItems: this.foodService.foodItems().length,
    decorations: this.decorationService.decorationThemes().length,
    vendors: this.vendorService.vendors().length
  }));

  recentMenuRequests = computed(() => this.menuRequestService.requests().slice(0, 5));
}
