import { Component } from '@angular/core';

@Component({
  selector: 'app-clients',
  imports: [],
  templateUrl: './clients.html',
  styleUrl: './clients.css',
  standalone: true
})
export class Clients {

}
