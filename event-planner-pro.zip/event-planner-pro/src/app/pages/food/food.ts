import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FoodService } from '../../services/food';
import { MenuRequestService } from '../../services/menu-request';

import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-food',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule],
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>🍽️ Food & Catering</h1>
        <p>Select food for your events</p>
        <input type="text" placeholder="Search food..." [(ngModel)]="search" class="search-input" />
      </div>

      <div class="items-grid">
        @for (food of filteredFoods(); track food.id) {
          <div class="item-card">
            <div class="item-image" [style.backgroundImage]="'url(' + food.image + ')'""></div>
            <div class="item-info">
              <h3>{{ food.name }}</h3>
              <p class="category">{{ food.category }}</p>
              <span class="type-badge" [class]="food.type.toLowerCase()">{{ food.type }}</span>
              <p class="price">₹{{ food.price }}</p>
              <button class="btn-add" (click)="openRequestForm(food.id)">Submit Need</button>
            </div>
          </div>
        }
      </div>

      <!-- Request Modal -->
      <div class="modal-backdrop" *ngIf="showRequestForm">
        <div class="modal">
          <h2>Submit Food Request</h2>
          <form [formGroup]="requestForm" (ngSubmit)="submitRequest()">
            <input type="text" formControlName="quantity" placeholder="Quantity (e.g. 10 plates)" />
            <textarea formControlName="notes" placeholder="Special instructions"></textarea>
            <button type="submit" [disabled]="!requestForm.valid">Submit</button>
            <button type="button" (click)="closeRequestForm()">Cancel</button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    .items-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 20px; }
    .item-card { border-radius: 12px; overflow: hidden; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: all 0.3s; }
    .item-card:hover { transform: translateY(-4px); box-shadow: 0 8px 16px rgba(0,0,0,0.15); }
    .item-image { width: 100%; height: 180px; background-size: cover; background-position: center; }
    .item-info { padding: 16px; }
    .item-info h3 { font-size: 16px; font-weight: 600; margin: 0 0 4px; }
    .category { font-size: 12px; color: #718096; margin: 4px 0; }
    .type-badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: 600; }
    .type-badge.veg { background: #c6f6d5; color: #22543d; }
    .type-badge.non-veg { background: #fed7d7; color: #742a2a; }
    .price { font-size: 18px; font-weight: 700; color: #667eea; margin: 8px 0; }
    .btn-add { width: 100%; padding: 8px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .item-card { background: #2d3748; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FoodComponent {
  foodService = inject(FoodService);
  fb = inject(FormBuilder);

  menuRequestService = inject(MenuRequestService);

  search = '';
  showRequestForm = false;
  selectedFoodId: string | null = null;
  requestForm = this.fb.group({
    quantity: ['', Validators.required],
    notes: ['']
  });

  filteredFoods() {
    const q = this.search.trim().toLowerCase();
    return this.foodService.foodItems().filter(f =>
      f.name.toLowerCase().includes(q) ||
      f.category.toLowerCase().includes(q)
    );
  }

  openRequestForm(foodId: string) {
    this.selectedFoodId = foodId;
    this.showRequestForm = true;
    this.requestForm.reset();
  }
  closeRequestForm() {
    this.showRequestForm = false;
    this.selectedFoodId = null;
  }
  submitRequest() {
    if (this.requestForm.valid && this.selectedFoodId) {
      const food = this.foodService.foodItems().find(f => f.id === this.selectedFoodId);
      this.menuRequestService.addRequest({
        type: 'Food',
        itemId: this.selectedFoodId,
        itemName: food?.name || '',
        quantity: this.requestForm.value.quantity,
        notes: this.requestForm.value.notes || ''
      });
      alert('Request submitted for food item!');
      this.closeRequestForm();
    }
  }
}
