import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink, CommonModule],
  templateUrl: './home.html',
  styleUrl: './home.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class Home {
  features = [
    { icon: '📅', title: 'Event Planning', desc: 'Create and manage all your events in one place' },
    { icon: '🍽️', title: 'Food & Catering', desc: 'Browse and select from premium catering options' },
    { icon: '🎨', title: 'Decorations', desc: 'Choose beautiful decoration themes' },
    { icon: '🎂', title: 'Cake Models', desc: 'Custom cake designs for every occasion' },
    { icon: '🏢', title: 'Vendor Management', desc: 'Connect with trusted event vendors' },
    { icon: '📊', title: 'Analytics', desc: 'Track budgets and event metrics' }
  ];
}
