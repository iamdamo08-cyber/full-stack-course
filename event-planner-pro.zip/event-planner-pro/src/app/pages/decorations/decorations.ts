import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { DecorationService } from '../../services/decoration';
import { MenuRequestService } from '../../services/menu-request';

import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-decorations',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule],
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>🎨 Stage Decorations</h1>
        <p>Choose beautiful decoration themes for your event</p>
        <input type="text" placeholder="Search decorations..." [(ngModel)]="search" class="search-input" />
      </div>

      <div class="items-grid">
        @for (theme of filteredThemes(); track theme.id) {
          <div class="theme-card">
            <div class="theme-preview" [style.backgroundImage]="'url(' + theme.previewImage + ')'""></div>
            <div class="theme-info">
              <h3>{{ theme.name }}</h3>
              <p class="style">{{ theme.style }} Theme</p>
              <p class="desc">{{ theme.description }}</p>
              <p class="price">₹{{ theme.price }}</p>
              <div class="colors">
                @for (color of theme.colors; track color) {
                  <div class="color-dot" [style.backgroundColor]="color"></div>
                }
              </div>
              <button class="btn-select" (click)="openRequestForm(theme.id)">Submit Need</button>
            </div>
          </div>
        }
      </div>

      <!-- Request Modal -->
      <div class="modal-backdrop" *ngIf="showRequestForm">
        <div class="modal">
          <h2>Submit Decoration Request</h2>
          <form [formGroup]="requestForm" (ngSubmit)="submitRequest()">
            <input type="text" formControlName="quantity" placeholder="Quantity/Details (e.g. 1 stage, 10 tables)" />
            <textarea formControlName="notes" placeholder="Special instructions"></textarea>
            <button type="submit" [disabled]="!requestForm.valid">Submit</button>
            <button type="button" (click)="closeRequestForm()">Cancel</button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    .items-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 24px; }
    .theme-card { border-radius: 12px; overflow: hidden; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: all 0.3s; }
    .theme-card:hover { transform: translateY(-8px); box-shadow: 0 12px 24px rgba(0,0,0,0.15); }
    .theme-preview { width: 100%; height: 200px; background-size: cover; background-position: center; }
    .theme-info { padding: 20px; }
    .theme-info h3 { font-size: 18px; font-weight: 600; margin: 0 0 4px; }
    .style { font-size: 12px; color: #667eea; font-weight: 600; margin: 4px 0; }
    .desc { font-size: 13px; color: #718096; margin: 8px 0; }
    .price { font-size: 20px; font-weight: 700; color: #f6ad55; margin: 8px 0; }
    .colors { display: flex; gap: 8px; margin: 12px 0; }
    .color-dot { width: 20px; height: 20px; border-radius: 50%; border: 2px solid #ddd; }
    .btn-select { width: 100%; padding: 10px; background: linear-gradient(135deg, #f6ad55 0%, #ed8936 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .theme-card { background: #2d3748; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DecorationsComponent {
  decorationService = inject(DecorationService);
  fb = inject(FormBuilder);

  menuRequestService = inject(MenuRequestService);

  search = '';
  showRequestForm = false;
  selectedThemeId: string | null = null;
  requestForm = this.fb.group({
    quantity: ['', Validators.required],
    notes: ['']
  });

  filteredThemes() {
    const q = this.search.trim().toLowerCase();
    return this.decorationService.decorationThemes().filter(t =>
      t.name.toLowerCase().includes(q) ||
      t.style.toLowerCase().includes(q)
    );
  }

  openRequestForm(themeId: string) {
    this.selectedThemeId = themeId;
    this.showRequestForm = true;
    this.requestForm.reset();
  }
  closeRequestForm() {
    this.showRequestForm = false;
    this.selectedThemeId = null;
  }
  submitRequest() {
    if (this.requestForm.valid && this.selectedThemeId) {
      const theme = this.decorationService.decorationThemes().find(t => t.id === this.selectedThemeId);
      this.menuRequestService.addRequest({
        type: 'Decoration',
        itemId: this.selectedThemeId,
        itemName: theme?.name || '',
        quantity: this.requestForm.value.quantity,
        notes: this.requestForm.value.notes || ''
      });
      alert('Request submitted for decoration!');
      this.closeRequestForm();
    }
  }
}
