import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { CakeService } from '../../services/cake';
import { MenuRequestService } from '../../services/menu-request';

import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-cakes',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule],
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, ReactiveFormsModule],
  template: `
    <div class="generic-page">
      <div class="page-header">
        <h1>🎂 Cake Models</h1>
        <p>Select the perfect cake for your special event</p>
        <input type="text" placeholder="Search cakes..." [(ngModel)]="search" class="search-input" />
      </div>

      <div class="cakes-grid">
        @for (cake of filteredCakes(); track cake.id) {
          <div class="cake-card">
            <div class="cake-image" [style.backgroundImage]="'url(' + cake.image + ')'""></div>
            <div class="cake-content">
              <h3>{{ cake.name }}</h3>
              <p class="desc">{{ cake.description }}</p>
              <div class="flavors">
                <strong>Flavors:</strong>
                <div class="flavor-tags">
                  @for (flavor of cake.flavors; track flavor) {
                    <span class="tag">{{ flavor }}</span>
                  }
                </div>
              </div>
              <div class="size-options">
                @for (serve of cake.serve; track serve.weight) {
                  <div class="size-option">
                    <span class="weight">{{ serve.weight }}</span>
                    <span class="servings">{{ serve.servings }} servings</span>
                    <span class="price">₹{{ serve.price }}</span>
                  </div>
                }
              </div>
              <button class="btn-add" (click)="openRequestForm(cake.id)">Submit Need</button>
            </div>
          </div>
        }
      </div>

      <!-- Request Modal -->
      <div class="modal-backdrop" *ngIf="showRequestForm">
        <div class="modal">
          <h2>Submit Cake Request</h2>
          <form [formGroup]="requestForm" (ngSubmit)="submitRequest()">
            <input type="text" formControlName="quantity" placeholder="Quantity (e.g. 2 cakes)" />
            <textarea formControlName="notes" placeholder="Special instructions"></textarea>
            <button type="submit" [disabled]="!requestForm.valid">Submit</button>
            <button type="button" (click)="closeRequestForm()">Cancel</button>
          </form>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .generic-page { padding: 32px; max-width: 1400px; margin: 0 auto; }
    .page-header { margin-bottom: 32px; }
    .page-header h1 { font-size: 32px; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin: 8px 0 0; }
    .cakes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
    .cake-card { border-radius: 12px; overflow: hidden; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.1); transition: all 0.3s; }
    .cake-card:hover { transform: translateY(-8px); box-shadow: 0 12px 24px rgba(0,0,0,0.15); }
    .cake-image { width: 100%; height: 200px; background-size: cover; background-position: center; }
    .cake-content { padding: 20px; }
    .cake-content h3 { font-size: 18px; font-weight: 600; margin: 0 0 8px; }
    .desc { font-size: 14px; color: #718096; margin: 8px 0; }
    .flavors { margin: 12px 0; }
    .flavors strong { display: block; margin-bottom: 8px; font-size: 13px; }
    .flavor-tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag { background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); color: #667eea; padding: 4px 10px; border-radius: 4px; font-size: 12px; }
    .size-options { margin: 12px 0; display: flex; flex-direction: column; gap: 8px; }
    .size-option { display: flex; justify-content: space-between; padding: 8px; background: #f7fafc; border-radius: 6px; font-size: 13px; }
    .weight { font-weight: 600; }
    .servings { color: #718096; }
    .price { font-weight: 700; color: #667eea; }
    .btn-add { width: 100%; padding: 10px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; margin-top: 12px; }
    :host-context(.dark-mode) .page-header h1 { color: #f0f4f8; }
    :host-context(.dark-mode) .cake-card { background: #2d3748; }
  `],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CakesComponent {
  cakeService = inject(CakeService);
  fb = inject(FormBuilder);

  menuRequestService = inject(MenuRequestService);

  search = '';
  showRequestForm = false;
  selectedCakeId: string | null = null;
  requestForm = this.fb.group({
    quantity: ['', Validators.required],
    notes: ['']
  });

  filteredCakes() {
    const q = this.search.trim().toLowerCase();
    return this.cakeService.cakes().filter(c =>
      c.name.toLowerCase().includes(q) ||
      c.flavors.some(f => f.toLowerCase().includes(q))
    );
  }

  openRequestForm(cakeId: string) {
    this.selectedCakeId = cakeId;
    this.showRequestForm = true;
    this.requestForm.reset();
  }
  closeRequestForm() {
    this.showRequestForm = false;
    this.selectedCakeId = null;
  }
  submitRequest() {
    if (this.requestForm.valid && this.selectedCakeId) {
      const cake = this.cakeService.cakes().find(c => c.id === this.selectedCakeId);
      this.menuRequestService.addRequest({
        type: 'Cake',
        itemId: this.selectedCakeId,
        itemName: cake?.name || '',
        quantity: this.requestForm.value.quantity,
        notes: this.requestForm.value.notes || ''
      });
      alert('Request submitted for cake!');
      this.closeRequestForm();
    }
  }
}
