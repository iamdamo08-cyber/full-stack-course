import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { EventService } from '../../services/event';
import { Event } from '../../models/event.model';

import { Expense } from '../../models/event.model';

@Component({
  selector: 'app-events',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatIconModule, MatButtonModule, MatInputModule, MatSelectModule],
  templateUrl: './events.html',
  styleUrl: './events.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EventsComponent {
  private eventService = inject(EventService);
  private fb = inject(FormBuilder);

  events = this.eventService.events;
  showForm = signal(false);
  searchQuery = signal('');
  filterType = signal<'all' | 'Wedding' | 'Corporate' | 'Birthday' | 'Conference'>('all');

  // Expense management
  showExpenseForm = signal<string | null>(null); // eventId or null
  expenseForm = this.fb.group({
    description: ['', Validators.required],
    amount: [0, [Validators.required, Validators.min(1)]],
    category: ['Other', Validators.required],
    imageUrl: ['']
  });

  form = this.fb.group({
    name: ['', Validators.required],
    type: ['Wedding', Validators.required],
    status: ['Upcoming', Validators.required],
    date: ['', Validators.required],
    location: ['', Validators.required],
    clientName: ['', Validators.required],
    budget: [0, [Validators.required, Validators.min(0)]],
    description: ['']
  });

  filteredEvents = computed(() => {
    let filtered = this.eventService.searchEvents(this.searchQuery());
    if (this.filterType() !== 'all') {
      filtered = filtered.filter(e => e.type === this.filterType());
    }
    return filtered;
  });

  createEvent(): void {
    if (this.form.valid) {
      const newEvent: Omit<Event, 'id' | 'createdAt' | 'updatedAt'> = {
        ...this.form.value as any,
        clientId: 'c' + Date.now(),
        vendorIds: [],
        foodItems: [],
        spentBudget: 0
        // expenses: [] // Not required, default undefined
      };
      this.eventService.addEvent(newEvent);
      this.form.reset({ type: 'Wedding', status: 'Upcoming' });
      this.showForm.set(false);
    }
  }

  // Expense logic
  getExpenses(event: Event): Expense[] {
    return event.expenses || [];
  }

  addExpense(event: Event): void {
    if (this.expenseForm.invalid) return;
    const expense: Expense = {
      id: 'exp' + Date.now(),
      description: this.expenseForm.value.description || '',
      amount: this.expenseForm.value.amount || 0,
      category: this.expenseForm.value.category as any,
      imageUrl: this.expenseForm.value.imageUrl || '',
      createdAt: new Date()
    };
    const updatedExpenses = [...(event.expenses || []), expense];
    this.eventService.updateEvent(event.id, { expenses: updatedExpenses });
    this.expenseForm.reset({ category: 'Other', amount: 0 });
    this.showExpenseForm.set(null);
  }

  removeExpense(event: Event, expenseId: string): void {
    const updatedExpenses = (event.expenses || []).filter(e => e.id !== expenseId);
    this.eventService.updateEvent(event.id, { expenses: updatedExpenses });
  }

  openExpenseForm(eventId: string): void {
    this.showExpenseForm.set(eventId);
    this.expenseForm.reset({ category: 'Other', amount: 0 });
  }

  closeExpenseForm(): void {
    this.showExpenseForm.set(null);
  }

  deleteEvent(id: string): void {
    if (confirm('Are you sure you want to delete this event?')) {
      this.eventService.deleteEvent(id);
    }
  }

  toggleEvent(id: string): void {
    const event = this.eventService.getEvent(id);
    if (event) {
      const newStatus = event.status === 'Upcoming' ? 'Completed' : 'Upcoming';
      this.eventService.updateEvent(id, { status: newStatus as any });
    }
  }

  onFilterChange(type: string): void {
    this.filterType.set(type as 'all' | 'Wedding' | 'Corporate' | 'Birthday' | 'Conference');
  }

  onSearchChange(query: string): void {
    this.searchQuery.set(query);
  }
}
