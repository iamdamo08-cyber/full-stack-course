import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  private darkModeSignal = signal<boolean>(this.getStoredTheme());
  darkMode = this.darkModeSignal.asReadonly();

  constructor() {}

  private getStoredTheme(): boolean {
    if (typeof localStorage === 'undefined') return false;
    const stored = localStorage.getItem('darkMode');
    return stored ? JSON.parse(stored) : false;
  }

  toggleDarkMode(): void {
    const newValue = !this.darkModeSignal();
    this.darkModeSignal.set(newValue);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('darkMode', JSON.stringify(newValue));
    }
    this.applyTheme(newValue);
  }

  setDarkMode(isDark: boolean): void {
    this.darkModeSignal.set(isDark);
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('darkMode', JSON.stringify(isDark));
    }
    this.applyTheme(isDark);
  }

  private applyTheme(isDark: boolean): void {
    const body = document.body;
    if (isDark) {
      body.classList.add('dark-mode');
    } else {
      body.classList.remove('dark-mode');
    }
  }
}
