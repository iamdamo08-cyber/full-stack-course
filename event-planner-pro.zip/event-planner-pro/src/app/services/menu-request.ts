import { Injectable, signal } from '@angular/core';

export interface MenuRequest {
  id: string;
  type: 'Food' | 'Cake' | 'Decoration';
  itemId: string;
  itemName: string;
  quantity: string;
  notes: string;
  createdAt: Date;
}

@Injectable({ providedIn: 'root' })
export class MenuRequestService {
  private requestsSignal = signal<MenuRequest[]>([]);
  requests = this.requestsSignal.asReadonly();

  addRequest(request: Omit<MenuRequest, 'id' | 'createdAt'>) {
    const newRequest: MenuRequest = {
      ...request,
      id: 'req' + Date.now(),
      createdAt: new Date()
    };
    this.requestsSignal.set([newRequest, ...this.requestsSignal()]);
  }
}
