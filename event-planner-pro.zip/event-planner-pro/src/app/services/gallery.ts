import { Injectable, signal } from '@angular/core';
import { GalleryItem } from '../models/gallery.model';

@Injectable({
  providedIn: 'root'
})
export class GalleryService {
  private galleryItemsSignal = signal<GalleryItem[]>(this.getDemoGallery());
  galleryItems = this.galleryItemsSignal.asReadonly();

  constructor() {}

  private getDemoGallery(): GalleryItem[] {
    return [
      {
        id: 'g1',
        eventId: '4',
        eventName: 'Corporate Annual Meet',
        clientName: 'Global Enterprises Ltd',
        images: [
          'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%231E3A8A%22 width=%22400%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ECorporate Event%3C/text%3E%3C/svg%3E'
        ],
        description: 'Annual company gathering with 500+ attendees',
        budget: 300000,
        spentBudget: 280000,
        completedAt: new Date(new Date().getFullYear() - 1, new Date().getMonth() + 5, 10)
      },
      {
        id: 'g2',
        eventId: '5',
        eventName: 'Sharma Wedding',
        clientName: 'Rajesh & Anjali Sharma',
        images: [
          'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23800020%22 width=%22400%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22%23FFD700%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EWedding%3C/text%3E%3C/svg%3E'
        ],
        description: 'Grand wedding ceremony with 1000+ guests',
        budget: 450000,
        spentBudget: 420000,
        completedAt: new Date(new Date().getFullYear() - 1, 2, 15)
      },
      {
        id: 'g3',
        eventId: '6',
        eventName: 'Tech Summit 2024',
        clientName: 'InnovateTech Solutions',
        images: [
          'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23000000%22 width=%22400%22 height=%22300%22/%3E%3Crect x=%2250%22 y=%2250%22 width=%2260%22 height=%2260%22 fill=%22%231E90FF%22/%3E%3Crect x=%22150%22 y=%2250%22 width=%2260%22 height=%2260%22 fill=%22%2300CED1%22/%3E%3Crect x=%22250%22 y=%2250%22 width=%2260%22 height=%2260%22 fill=%22%231E90FF%22/%3E%3Ctext x=%2250%25%22 y=%2280%25%22 font-size=%2228%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ETech Summit%3C/text%3E%3C/svg%3E'
        ],
        description: '3-day technology conference with 2000+ attendees',
        budget: 250000,
        spentBudget: 230000,
        completedAt: new Date(new Date().getFullYear() - 1, 8, 20)
      }
    ];
  }

  getGalleryItem(id: string): GalleryItem | undefined {
    return this.galleryItemsSignal().find(g => g.id === id);
  }

  addGalleryItem(item: Omit<GalleryItem, 'id'>): GalleryItem {
    const newItem: GalleryItem = {
      ...item,
      id: Date.now().toString()
    };
    this.galleryItemsSignal.update(items => [...items, newItem]);
    return newItem;
  }

  deleteGalleryItem(id: string): void {
    this.galleryItemsSignal.update(items => items.filter(g => g.id !== id));
  }
}
