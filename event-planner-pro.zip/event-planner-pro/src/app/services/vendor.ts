import { Injectable, signal } from '@angular/core';
import { Vendor, VendorType } from '../models/vendor.model';

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private vendorsSignal = signal<Vendor[]>(this.getDemoVendors());
  vendors = this.vendorsSignal.asReadonly();

  constructor() {}

  private getDemoVendors(): Vendor[] {
    return [
      {
        id: 'v1',
        name: 'Royal Catering Services',
        type: 'Catering',
        email: 'royal@catering.com',
        phone: '+91-98765-43210',
        address: '123 Food Street, Delhi',
        rating: 4.8,
        pricePerEvent: 50000,
        description: 'Premium catering with 20+ years experience',
        createdAt: new Date()
      },
      {
        id: 'v2',
        name: 'Radiant Decorators',
        type: 'Decoration',
        email: 'radiant@decor.com',
        phone: '+91-98765-12345',
        address: '456 Design Lane, Mumbai',
        rating: 4.7,
        pricePerEvent: 40000,
        description: 'Creative decoration team for all event themes',
        createdAt: new Date()
      },
      {
        id: 'v3',
        name: 'SnapShot Photography',
        type: 'Photography',
        email: 'snapshot@photo.com',
        phone: '+91-98765-67890',
        address: '789 Camera Road, Bangalore',
        rating: 4.9,
        pricePerEvent: 35000,
        description: 'Professional photography with drone coverage',
        createdAt: new Date()
      },
      {
        id: 'v4',
        name: 'DJ Sound Masters',
        type: 'Music',
        email: 'masters@djsound.com',
        phone: '+91-98765-11111',
        address: '321 Music Square, Pune',
        rating: 4.6,
        pricePerEvent: 25000,
        description: 'Professional DJs with latest sound systems',
        createdAt: new Date()
      },
      {
        id: 'v5',
        name: 'Festival Catering Co.',
        type: 'Catering',
        email: 'festival@catering.co.in',
        phone: '+91-98765-22222',
        address: '654 Spice Garden, Hyderabad',
        rating: 4.5,
        pricePerEvent: 35000,
        description: 'Authentic Indian and continental cuisine',
        createdAt: new Date()
      }
    ];
  }

  getVendor(id: string): Vendor | undefined {
    return this.vendorsSignal().find(v => v.id === id);
  }

  getVendorsByType(type: VendorType): Vendor[] {
    return this.vendorsSignal().filter(v => v.type === type);
  }

  addVendor(vendor: Omit<Vendor, 'id' | 'createdAt'>): Vendor {
    const newVendor: Vendor = {
      ...vendor,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    this.vendorsSignal.update(vendors => [...vendors, newVendor]);
    return newVendor;
  }

  updateVendor(id: string, updates: Partial<Vendor>): Vendor | null {
    let updatedVendor: Vendor | null = null;
    this.vendorsSignal.update(vendors =>
      vendors.map(v =>
        v.id === id ? (updatedVendor = { ...v, ...updates }) : v
      )
    );
    return updatedVendor;
  }

  deleteVendor(id: string): void {
    this.vendorsSignal.update(vendors => vendors.filter(v => v.id !== id));
  }

  searchVendors(query: string): Vendor[] {
    const q = query.toLowerCase();
    return this.vendorsSignal().filter(v =>
      v.name.toLowerCase().includes(q) ||
      v.email.toLowerCase().includes(q) ||
      v.type.toLowerCase().includes(q)
    );
  }
}
