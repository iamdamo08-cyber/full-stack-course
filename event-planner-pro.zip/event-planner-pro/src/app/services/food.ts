import { Injectable, signal, computed } from '@angular/core';
import { FoodItem, FoodCategory } from '../models/food.model';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
  private foodItemsSignal = signal<FoodItem[]>(this.getDemoFoodItems());
  foodItems = this.foodItemsSignal.asReadonly();

  totalItems = computed(() => this.foodItemsSignal().length);

  constructor() {}

  private getDemoFoodItems(): FoodItem[] {
    return [
      {
        id: 'f1',
        name: 'Paneer Tikka',
        category: 'Starters',
        type: 'Veg',
        price: 350,
        description: 'Succulent paneer pieces marinated in yogurt spices',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23f5a623%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EPaneer Tikka%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      },
      {
        id: 'f2',
        name: 'Chicken Biryani',
        category: 'Main Course',
        type: 'Non-Veg',
        price: 500,
        description: 'Fragrant basmati rice cooked with tender chicken',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%238B7355%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EChicken Biryani%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      },
      {
        id: 'f3',
        name: 'Pasta Alfredo',
        category: 'Main Course',
        type: 'Veg',
        price: 450,
        description: 'Creamy parmesan sauce with fresh pasta',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23FFE4B5%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22black%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EPasta Alfredo%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      },
      {
        id: 'f4',
        name: 'Mocktails',
        category: 'Beverages',
        type: 'Veg',
        price: 150,
        description: 'Refreshing mixed fruit mocktails',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23FF69B4%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EMocktails%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      },
      {
        id: 'f5',
        name: 'Chocolate Fountain',
        category: 'Desserts',
        type: 'Veg',
        price: 2000,
        description: 'Interactive chocolate fountain with fruits',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23654321%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EChocolate Fountain%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      },
      {
        id: 'f6',
        name: 'Ice Cream Bar',
        category: 'Desserts',
        type: 'Veg',
        price: 1500,
        description: 'Self-serve ice cream with topping bar',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22200%22%3E%3Crect fill=%22%23FFB6C1%22 width=%22300%22 height=%22200%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2232%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EIce Cream Bar%3C/text%3E%3C/svg%3E',
        createdAt: new Date()
      }
    ];
  }

  getFoodItem(id: string): FoodItem | undefined {
    return this.foodItemsSignal().find(f => f.id === id);
  }

  getFoodsByCategory(category: FoodCategory): FoodItem[] {
    return this.foodItemsSignal().filter(f => f.category === category);
  }

  addFoodItem(food: Omit<FoodItem, 'id' | 'createdAt'>): FoodItem {
    const newFood: FoodItem = {
      ...food,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    this.foodItemsSignal.update(items => [...items, newFood]);
    return newFood;
  }

  updateFoodItem(id: string, updates: Partial<FoodItem>): FoodItem | null {
    let updatedFood: FoodItem | null = null;
    this.foodItemsSignal.update(items =>
      items.map(f =>
        f.id === id ? (updatedFood = { ...f, ...updates }) : f
      )
    );
    return updatedFood;
  }

  deleteFoodItem(id: string): void {
    this.foodItemsSignal.update(items => items.filter(f => f.id !== id));
  }
}
