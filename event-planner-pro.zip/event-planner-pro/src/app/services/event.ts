import { Injectable, signal, computed } from '@angular/core';
import { Event, EventType, EventStatus } from '../models/event.model';

@Injectable({
  providedIn: 'root'
})
export class EventService {
  private eventsSignal = signal<Event[]>(this.getDemoEvents());
  events = this.eventsSignal.asReadonly();
  
  totalEvents = computed(() => this.eventsSignal().length);
  upcomingEvents = computed(() => 
    this.eventsSignal().filter(e => e.status === 'Upcoming').length
  );
  completedEvents = computed(() => 
    this.eventsSignal().filter(e => e.status === 'Completed').length
  );
  totalRevenue = computed(() => 
    this.eventsSignal().reduce((sum, e) => sum + e.spentBudget, 0)
  );

  constructor() {}

  private getDemoEvents(): Event[] {
    const now = new Date();
    return [
      {
        id: '1',
        name: 'Royal Wedding 2025',
        type: 'Wedding',
        status: 'Upcoming',
        date: new Date(now.getFullYear(), now.getMonth() + 2, 15),
        location: 'Grand Palace Ballroom, Delhi',
        clientId: 'c1',
        clientName: 'Raj & Priya',
        budget: 500000,
        spentBudget: 250000,
        vendorIds: ['v1', 'v2'],
        foodItems: ['f1', 'f2', 'f3'],
        decorationThemeId: 'd1',
        cakeId: 'cake1',
        description: 'A grand royal wedding celebration',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '2',
        name: 'Tech Conference 2025',
        type: 'Corporate',
        status: 'Upcoming',
        date: new Date(now.getFullYear(), now.getMonth() + 1, 20),
        location: 'IT Hub Convention Center, Bangalore',
        clientId: 'c2',
        clientName: 'TechCorp India',
        budget: 200000,
        spentBudget: 150000,
        vendorIds: ['v3', 'v4'],
        foodItems: ['f4', 'f5', 'f6'],
        decorationThemeId: 'd4',
        description: '3-day technology conference',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '3',
        name: 'Birthday Bash',
        type: 'Birthday',
        status: 'Upcoming',
        date: new Date(now.getFullYear(), now.getMonth(), 25),
        location: 'Rainbow Resort, Mumbai',
        clientId: 'c3',
        clientName: 'Aisha Sharma',
        budget: 100000,
        spentBudget: 75000,
        vendorIds: ['v1', 'v5'],
        foodItems: ['f2', 'f3', 'f5'],
        cakeId: 'cake2',
        description: '30th Birthday celebration',
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: '4',
        name: 'Corporate Annual Meet',
        type: 'Corporate',
        status: 'Completed',
        date: new Date(now.getFullYear() - 1, now.getMonth() + 5, 10),
        location: 'Azure Conference Hall, Pune',
        clientId: 'c4',
        clientName: 'Global Enterprises Ltd',
        budget: 300000,
        spentBudget: 280000,
        vendorIds: ['v2', 'v3'],
        foodItems: ['f1', 'f4', 'f6'],
        decorationThemeId: 'd5',
        description: 'Annual company gathering',
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];
  }

  getEvent(id: string): Event | undefined {
    return this.eventsSignal().find(e => e.id === id);
  }

  addEvent(event: Omit<Event, 'id' | 'createdAt' | 'updatedAt'>): Event {
    const newEvent: Event = {
      ...event,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.eventsSignal.update(events => [...events, newEvent]);
    return newEvent;
  }

  updateEvent(id: string, updates: Partial<Event>): Event | null {
    let updatedEvent: Event | null = null;
    this.eventsSignal.update(events =>
      events.map(e =>
        e.id === id
          ? (updatedEvent = { ...e, ...updates, updatedAt: new Date() })
          : e
      )
    );
    return updatedEvent;
  }

  deleteEvent(id: string): void {
    this.eventsSignal.update(events => events.filter(e => e.id !== id));
  }

  getEventsByStatus(status: EventStatus): Event[] {
    return this.eventsSignal().filter(e => e.status === status);
  }

  getEventsByType(type: EventType): Event[] {
    return this.eventsSignal().filter(e => e.type === type);
  }

  searchEvents(query: string): Event[] {
    const q = query.toLowerCase();
    return this.eventsSignal().filter(e =>
      e.name.toLowerCase().includes(q) ||
      e.clientName.toLowerCase().includes(q) ||
      e.location.toLowerCase().includes(q)
    );
  }
}
