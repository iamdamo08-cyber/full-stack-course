import { Injectable, signal } from '@angular/core';
import { DecorationTheme } from '../models/decoration.model';

@Injectable({
  providedIn: 'root'
})
export class DecorationService {
  private decorationThemesSignal = signal<DecorationTheme[]>(this.getDemoThemes());
  decorationThemes = this.decorationThemesSignal.asReadonly();

  constructor() {}

  private getDemoThemes(): DecorationTheme[] {
    return [
      {
        id: 'd1',
        name: 'Royal Palace Theme',
        description: 'Luxurious gold and maroon theme with grand chandeliers',
        price: 50000,
        previewImage: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23800020%22 width=%22400%22 height=%22300%22/%3E%3Ccircle cx=%22200%22 cy=%22150%22 r=%2250%22 fill=%22%23FFD700%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ERoyal Palace%3C/text%3E%3C/svg%3E',
        colors: ['#800020', '#FFD700', '#FFFFFF'],
        style: 'Royal',
        createdAt: new Date()
      },
      {
        id: 'd2',
        name: 'Floral Garden Theme',
        description: 'Beautiful floral arrangements with pastel colors',
        price: 40000,
        previewImage: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23FFB6D9%22 width=%22400%22 height=%22300%22/%3E%3Ccircle cx=%22200%22 cy=%22150%22 r=%2230%22 fill=%22%23FF69B4%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EFloral Garden%3C/text%3E%3C/svg%3E',
        colors: ['#FFB6D9', '#FF69B4', '#90EE90'],
        style: 'Floral',
        createdAt: new Date()
      },
      {
        id: 'd3',
        name: 'Minimal Modern Stage',
        description: 'Clean and contemporary with geometric patterns',
        price: 35000,
        previewImage: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23FFFFFF%22 width=%22400%22 height=%22300%22/%3E%3Crect x=%2250%22 y=%2250%22 width=%22100%22 height=%22200%22 fill=%22%23000000%22/%3E%3Crect x=%22250%22 y=%2250%22 width=%22100%22 height=%22200%22 fill=%22%23000000%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 fill=%22black%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EModern%3C/text%3E%3C/svg%3E',
        colors: ['#FFFFFF', '#000000', '#CCCCCC'],
        style: 'Modern',
        createdAt: new Date()
      },
      {
        id: 'd4',
        name: 'Traditional Indian Wedding',
        description: 'Rich colors with traditional motifs and patterns',
        price: 55000,
        previewImage: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23DC143C%22 width=%22400%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 fill=%22%23FFD700%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ETraditional Indian%3C/text%3E%3C/svg%3E',
        colors: ['#DC143C', '#FFD700', '#228B22'],
        style: 'Traditional',
        createdAt: new Date()
      },
      {
        id: 'd5',
        name: 'Corporate LED Backdrop',
        description: 'Professional LED screens with dynamic lighting',
        price: 60000,
        previewImage: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22400%22 height=%22300%22%3E%3Crect fill=%22%23000000%22 width=%22400%22 height=%22300%22/%3E%3Crect x=%2250%22 y=%2250%22 width=%2360%22 height=%2260%22 fill=%22%230000FF%22/%3E%3Crect x=%22150%22 y=%2250%22 width=%2260%22 height=%2260%22 fill=%22%231E90FF%22/%3E%3Crect x=%22250%22 y=%2250%22 width=%2260%22 height=%2260%22 fill=%22%2300CED1%22/%3E%3Ctext x=%2250%25%22 y=%2280%25%22 font-size=%2224%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ECorporate LED%3C/text%3E%3C/svg%3E',
        colors: ['#000000', '#0000FF', '#1E90FF'],
        style: 'Corporate',
        createdAt: new Date()
      }
      ,
      {
        id: 'd6',
        name: 'Stage: Classic Drapes',
        description: 'Stage setup using the provided stage1.webp image',
        price: 30000,
        previewImage: 'assets/images/decorations/stage1.webp',
        colors: ['#8B4513', '#FFD700', '#FFFFFF'],
        style: 'Classic',
        createdAt: new Date()
      },
      {
        id: 'd7',
        name: 'Stage: Floral Accent',
        description: 'Stage setup using the provided stage2.webp image',
        price: 32000,
        previewImage: 'assets/images/decorations/stage2.webp',
        colors: ['#FFB6D9', '#FF69B4', '#90EE90'],
        style: 'Floral',
        createdAt: new Date()
      },
      {
        id: 'd8',
        name: 'Stage: Minimal Modern',
        description: 'Stage setup using the provided stage3.webp image',
        price: 35000,
        previewImage: 'assets/images/decorations/stage3.webp',
        colors: ['#WHITE', '#000000', '#CCCCCC'],
        style: 'Modern',
        createdAt: new Date()
      },
      {
        id: 'd9',
        name: 'Stage: Festive Lights',
        description: 'Stage setup using the provided stage4.webp image',
        price: 40000,
        previewImage: 'assets/images/decorations/stage4.webp',
        colors: ['#DC143C', '#FFD700', '#228B22'],
        style: 'Festive',
        createdAt: new Date()
      }
    ];
  }

  getTheme(id: string): DecorationTheme | undefined {
    return this.decorationThemesSignal().find(t => t.id === id);
  }

  addTheme(theme: Omit<DecorationTheme, 'id' | 'createdAt'>): DecorationTheme {
    const newTheme: DecorationTheme = {
      ...theme,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    this.decorationThemesSignal.update(themes => [...themes, newTheme]);
    return newTheme;
  }

  updateTheme(id: string, updates: Partial<DecorationTheme>): DecorationTheme | null {
    let updatedTheme: DecorationTheme | null = null;
    this.decorationThemesSignal.update(themes =>
      themes.map(t =>
        t.id === id ? (updatedTheme = { ...t, ...updates }) : t
      )
    );
    return updatedTheme;
  }

  deleteTheme(id: string): void {
    this.decorationThemesSignal.update(themes => themes.filter(t => t.id !== id));
  }
}
