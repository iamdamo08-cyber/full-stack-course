import { Injectable, signal } from '@angular/core';
import { CakeModel } from '../models/cake.model';

@Injectable({
  providedIn: 'root'
})
export class CakeService {
  private cakesSignal = signal<CakeModel[]>(this.getDemoCakes());
  cakes = this.cakesSignal.asReadonly();

  constructor() {}

  private getDemoCakes(): CakeModel[] {
    return [
      {
        id: 'cake1',
        name: '3-Tier Wedding Cake',
        description: 'Classic white wedding cake with delicate icing',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22400%22%3E%3Crect fill=%22%23FFFACD%22 width=%22300%22 height=%22400%22/%3E%3Crect x=%2250%22 y=%22250%22 width=%22200%22 height=%2270%22 fill=%22%23F5F5DC%22 stroke=%22%23DAA520%22 stroke-width=%222%22/%3E%3Crect x=%2275%22 y=%22170%22 width=%22150%22 height=%2270%22 fill=%22%23F5F5DC%22 stroke=%22%23DAA520%22 stroke-width=%222%22/%3E%3Crect x=%22100%22 y=%2290%22 width=%22100%22 height=%2270%22 fill=%22%23F5F5DC%22 stroke=%22%23DAA520%22 stroke-width=%222%22/%3E%3Ctext x=%2250%25%22 y=%2230%25%22 font-size=%2224%22 fill=%22%23000000%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EWedding Cake%3C/text%3E%3C/svg%3E',
        basePrice: 5000,
        flavors: ['Vanilla', 'Chocolate', 'Strawberry'],
        serve: [
          { weight: '1kg', servings: 10, price: 5000 },
          { weight: '2kg', servings: 20, price: 8000 },
          { weight: '3kg', servings: 30, price: 11000 }
        ],
        createdAt: new Date()
      },
      {
        id: 'cake2',
        name: 'Chocolate Drip Cake',
        description: 'Moist chocolate cake with chocolate ganache drip',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect fill=%22%23654321%22 width=%22300%22 height=%22300%22/%3E%3Ccircle cx=%22150%22 cy=%22100%22 r=%2260%22 fill=%22%238B4513%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2220%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EChocolate Drip%3C/text%3E%3C/svg%3E',
        basePrice: 4000,
        flavors: ['Dark Chocolate', 'Milk Chocolate', 'White Chocolate'],
        serve: [
          { weight: '1kg', servings: 10, price: 4000 },
          { weight: '2kg', servings: 20, price: 7000 },
          { weight: '3kg', servings: 30, price: 9500 }
        ],
        createdAt: new Date()
      },
      {
        id: 'cake3',
        name: 'Cartoon Theme Cake',
        description: 'Colorful cake with custom cartoon characters',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect fill=%22%23FFB6D9%22 width=%22300%22 height=%22300%22/%3E%3Ccircle cx=%2275%22 cy=%22150%22 r=%2240%22 fill=%22%23FF69B4%22/%3E%3Ccircle cx=%22225%22 cy=%22150%22 r=%2240%22 fill=%22%231E90FF%22/%3E%3Ctext x=%2250%25%22 y=%2280%25%22 font-size=%2220%22 fill=%22white%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3ECartoon Cake%3C/text%3E%3C/svg%3E',
        basePrice: 3500,
        flavors: ['Vanilla', 'Strawberry', 'Bubblegum'],
        serve: [
          { weight: '1kg', servings: 10, price: 3500 },
          { weight: '2kg', servings: 20, price: 6000 },
          { weight: '3kg', servings: 30, price: 8500 }
        ],
        createdAt: new Date()
      },
      {
        id: 'cake4',
        name: 'Minimal White Elegant Cake',
        description: 'Simple yet elegant white cake with gold accents',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect fill=%22%23FFFFFF%22 width=%22300%22 height=%22300%22/%3E%3Crect x=%2250%22 y=%2275%22 width=%22200%22 height=%22200%22 fill=%22%23F5F5F5%22 stroke=%22%23DAA520%22 stroke-width=%223%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2220%22 fill=%22%23000000%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EEllegant White%3C/text%3E%3C/svg%3E',
        basePrice: 4500,
        flavors: ['Vanilla', 'Champagne'],
        serve: [
          { weight: '1kg', servings: 10, price: 4500 },
          { weight: '2kg', servings: 20, price: 7500 },
          { weight: '3kg', servings: 30, price: 10000 }
        ],
        createdAt: new Date()
      },
      {
        id: 'cake5',
        name: 'Custom Photo Cake',
        description: 'Your custom photo printed on the cake',
        image: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect fill=%22%23E6E6FA%22 width=%22300%22 height=%22300%22/%3E%3Crect x=%2250%22 y=%2250%22 width=%22200%22 height=%22200%22 fill=%22%23DDA0DD%22 stroke=%22%23000000%22 stroke-width=%222%22/%3E%3Ctext x=%2250%25%22 y=%2280%25%22 font-size=%2220%22 fill=%22%23000000%22 text-anchor=%22middle%22 dominant-baseline=%22middle%22%3EPhoto Cake%3C/text%3E%3C/svg%3E',
        basePrice: 6000,
        flavors: ['Vanilla', 'Chocolate'],
        serve: [
          { weight: '1kg', servings: 10, price: 6000 },
          { weight: '2kg', servings: 20, price: 9500 },
          { weight: '3kg', servings: 30, price: 12500 }
        ],
        createdAt: new Date()
      }
      ,
      {
        id: 'cake_user',
        name: 'Happy Birthday Special',
        description: 'User-provided cake image (copy your file to assets/images/cakes/)',
        image: 'assets/images/cakes/cake_user.jpg',
        basePrice: 2500,
        flavors: ['Vanilla', 'Buttercream'],
        serve: [
          { weight: '1kg', servings: 10, price: 2500 },
          { weight: '2kg', servings: 20, price: 4500 },
          { weight: '3kg', servings: 30, price: 6500 }
        ],
        createdAt: new Date()
      }
    ];
  }

  getCake(id: string): CakeModel | undefined {
    return this.cakesSignal().find(c => c.id === id);
  }

  addCake(cake: Omit<CakeModel, 'id' | 'createdAt'>): CakeModel {
    const newCake: CakeModel = {
      ...cake,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    this.cakesSignal.update(cakes => [...cakes, newCake]);
    return newCake;
  }

  updateCake(id: string, updates: Partial<CakeModel>): CakeModel | null {
    let updatedCake: CakeModel | null = null;
    this.cakesSignal.update(cakes =>
      cakes.map(c =>
        c.id === id ? (updatedCake = { ...c, ...updates }) : c
      )
    );
    return updatedCake;
  }

  deleteCake(id: string): void {
    this.cakesSignal.update(cakes => cakes.filter(c => c.id !== id));
  }
}
