import { Component, output, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { ThemeService } from '../../services/theme';

interface NavItem {
  label: string;
  icon: string;
  route: string;
}

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, MatIconModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidebarComponent {
  private themeService = inject(ThemeService);
  darkMode = this.themeService.darkMode;
  isCollapsed = signal(false);
  toggleCollapse = output<boolean>();

  navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'dashboard', route: '/dashboard' },
    { label: 'Events', icon: 'event', route: '/events' },
    { label: 'Create Event', icon: 'add_circle', route: '/create-event' },
    { label: 'Food & Catering', icon: 'restaurant', route: '/food' },
    { label: 'Decorations', icon: 'palette', route: '/decorations' },
    { label: 'Cakes', icon: 'cake', route: '/cakes' },
    { label: 'Vendors', icon: 'business', route: '/vendors' },
    { label: 'Gallery', icon: 'photo_library', route: '/gallery' },
    { label: 'Reports', icon: 'bar_chart', route: '/reports' },
    { label: 'Settings', icon: 'settings', route: '/settings' }
  ];

  toggleSidebar(): void {
    this.isCollapsed.update(val => !val);
    this.toggleCollapse.emit(this.isCollapsed());
  }

  toggleTheme(): void {
    this.themeService.toggleDarkMode();
  }
}
