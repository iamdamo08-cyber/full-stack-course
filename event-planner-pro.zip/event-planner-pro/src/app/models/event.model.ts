export type EventType = 'Wedding' | 'Corporate' | 'Birthday' | 'Conference';
export type EventStatus = 'Upcoming' | 'Completed' | 'Cancelled';

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: 'Food' | 'Decoration' | 'Cake' | 'Other';
  imageUrl?: string;
  createdAt: Date;
}

export interface Event {
  id: string;
  name: string;
  type: EventType;
  status: EventStatus;
  date: Date;
  location: string;
  clientId: string;
  clientName: string;
  budget: number;
  spentBudget: number;
  vendorIds: string[];
  foodItems: string[]; // IDs of selected food items
  decorationThemeId?: string;
  cakeId?: string;
  description: string;
  imageBanner?: string; // Base64 or URL
  expenses?: Expense[];
  createdAt: Date;
  updatedAt: Date;
}
