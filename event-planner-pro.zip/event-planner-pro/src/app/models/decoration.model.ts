export interface DecorationTheme {
  id: string;
  name: string;
  description: string;
  price: number;
  previewImage: string; // Base64 or URL
  colors: string[];
  style: string; // 'Royal' | 'Floral' | 'Modern' | 'Traditional' | 'Corporate'
  createdAt: Date;
}
