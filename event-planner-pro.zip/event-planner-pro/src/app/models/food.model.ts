export type FoodCategory = 'Starters' | 'Main Course' | 'Desserts' | 'Beverages';
export type FoodType = 'Veg' | 'Non-Veg';

export interface FoodItem {
  id: string;
  name: string;
  category: FoodCategory;
  type: FoodType;
  price: number;
  description: string;
  image: string; // Base64 or URL
  createdAt: Date;
}
