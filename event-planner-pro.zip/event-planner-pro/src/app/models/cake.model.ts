export interface CakeModel {
  id: string;
  name: string;
  description: string;
  image: string; // Base64 or URL
  basePrice: number;
  flavors: string[];
  serve: { weight: string; servings: number; price: number }[];
  createdAt: Date;
}
