export interface GalleryItem {
  id: string;
  eventId: string;
  eventName: string;
  clientName: string;
  images: string[]; // Base64 or URLs
  description: string;
  budget: number;
  spentBudget: number;
  completedAt: Date;
}
