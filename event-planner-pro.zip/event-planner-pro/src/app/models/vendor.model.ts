export type VendorType = 'Catering' | 'Decoration' | 'Photography' | 'Music';

export interface Vendor {
  id: string;
  name: string;
  type: VendorType;
  email: string;
  phone: string;
  address: string;
  rating: number; // 0-5
  pricePerEvent: number;
  description: string;
  image?: string;
  createdAt: Date;
}
