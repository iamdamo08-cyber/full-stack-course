import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Service {
  turnOn(){
    return 'AC IS ON+++'
  }
        turnOff(){
    return 'AC IS OFF---'
  }
}