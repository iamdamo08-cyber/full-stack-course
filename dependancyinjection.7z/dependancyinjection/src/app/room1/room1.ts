import { Component } from '@angular/core';
import { Service } from '../service';

@Component({
  selector: 'app-room1',
  imports: [],
  templateUrl: './room1.html',
  styleUrl: './room1.css',
})
export class Room1 {
  message='';
  constructor (private acservice: Service){
  }
  onAc(){
    this.message=this.acservice.turnOn();
  }

  OffAc(){
    this.message=this.acservice.turnOff();
  }
}
